import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
from datetime import datetime

def plot_gantt_from_csv(csv_path):
    # Load CSV
    df = pd.read_csv(csv_path, delimiter=';')
    df["start"] = pd.to_datetime(df["start"])
    df["end"] = pd.to_datetime(df["end"])
    df.sort_values(by=["task", "start"], inplace=True)

    # Setup canvas
    fig, ax = plt.subplots(figsize=(16, 10))
    tasks = df["task"].unique()
    workers = df["worker"].unique()  # Get unique workers
    
    # Create colormap based on workers instead of tasks
    cmap = plt.cm.get_cmap("tab20", len(workers))
    worker_color_map = {worker: cmap(i) for i, worker in enumerate(workers)}
    
    task_indices = {task: i for i, task in enumerate(tasks)}

    yticks = list(range(len(tasks)))
    ylabels = tasks

    for _, row in df.iterrows():
        task = row["task"]
        worker = row["worker"]
        idx = task_indices[task]
        start = row["start"]
        end = row["end"]
        duration = end - start

        ax.barh(
            y=idx,
            left=start,
            width=duration,
            height=0.4,
            color=worker_color_map[worker],  # Assign color based on worker
            edgecolor="black"
        )

        ax.text(
            start + duration / 2,
            idx,
            worker,
            ha="center",
            va="center",
            fontsize=8,
            color="white"
        )

    # Add a legend to identify workers by color
    from matplotlib.patches import Patch
    legend_elements = [Patch(facecolor=worker_color_map[worker], 
                            edgecolor='black',
                            label=worker) for worker in workers]
    ax.legend(handles=legend_elements, loc='upper right', title='Workers')

    # Format axis
    ax.set_yticks(yticks)
    ax.set_yticklabels(ylabels)
    ax.set_xlabel("Time")
    ax.set_title("📋 Task Schedule Gantt Chart (Workers Colored)")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
    ax.grid(True, axis="x", linestyle="--", alpha=0.5)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    plot_gantt_from_csv("logs/massive_planning_schedule_export.csv")