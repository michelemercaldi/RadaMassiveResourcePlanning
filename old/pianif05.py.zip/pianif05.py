# ebom_scheduler.py
import random
from datetime import datetime, timedelta
from collections import defaultdict
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import csv

# CONFIG
WORK_HOURS_PER_SHIFT = 8
WORK_DAYS_PER_MONTH = 20
UTILIZATION_THRESHOLD = 0.9

# User inputs
SHIFTS_PER_DAY = 2
GAP_BETWEEN_PHASES_HOURS = 8
GAP_BETWEEN_MBOM_AND_OTHERS_DAYS = 30  # Enforce one-month gap

TOTAL_MONTHS = 15
START_DATE = datetime(2025, 1, 1)

# PHASES
PHASES = ["mbom", "workInstruction", "routing"]

# Generate random EBOMs and DTRs
def generate_random_eboms(num_eboms: int):
    eboms = []
    for i in range(num_eboms):
        release_date = START_DATE + timedelta(days=random.randint(0, TOTAL_MONTHS * 30))
        dtrs = []
        for _ in range(random.randint(1, 4)):
            dtr = []
            # mbom phase
            mbom_duration = random.randint(4, 16)
            mbom_start = release_date + timedelta(days=random.randint(0, 10))
            mbom_deadline = mbom_start + timedelta(days=random.randint(5, 15))
            dtr.append({
                'phase': 'mbom',
                'duration': mbom_duration,
                'deadline': mbom_deadline
            })

            # workInstruction phase
            wi_duration = random.randint(4, 16)
            wi_start = mbom_deadline + timedelta(days=GAP_BETWEEN_MBOM_AND_OTHERS_DAYS)
            wi_deadline = wi_start + timedelta(days=random.randint(5, 15))
            dtr.append({
                'phase': 'workInstruction',
                'duration': wi_duration,
                'deadline': wi_deadline
            })

            # routing phase
            routing_duration = random.randint(4, 16)
            routing_start = wi_deadline + timedelta(days=random.randint(1, 3))
            routing_deadline = routing_start + timedelta(days=random.randint(5, 15))
            dtr.append({
                'phase': 'routing',
                'duration': routing_duration,
                'deadline': routing_deadline
            })

            dtrs.append(dtr)
        eboms.append({
            'id': f"EBOM_{i+1}",
            'release_date': release_date,
            'dtrs': dtrs
        })
    return eboms

# Worker calendar scheduling per month
def schedule_eboms(eboms):
    schedule = defaultdict(list)
    workers_needed_per_month = defaultdict(int)

    for month_index in range(TOTAL_MONTHS):
        month_start = START_DATE + timedelta(days=month_index * 30)
        month_end = month_start + timedelta(days=30)
        available_hours = SHIFTS_PER_DAY * WORK_HOURS_PER_SHIFT * WORK_DAYS_PER_MONTH

        monthly_tasks = []
        for ebom in eboms:
            if ebom['release_date'] > month_end:
                continue
            for dtr in ebom['dtrs']:
                for task in dtr:
                    if month_start <= task['deadline'] <= month_end:
                        monthly_tasks.append((ebom['id'], task))

        total_task_hours = sum(task['duration'] for _, task in monthly_tasks)
        min_workers = int(total_task_hours / (available_hours * UTILIZATION_THRESHOLD)) + 1
        workers_needed_per_month[month_index + 1] = min_workers

        # Assign tasks (basic)
        worker_times = [0] * min_workers
        for ebom_id, task in monthly_tasks:
            assigned = False
            for idx in range(min_workers):
                if worker_times[idx] + task['duration'] <= available_hours:
                    start_time = month_start + timedelta(hours=worker_times[idx])
                    schedule[ebom_id].append({
                        'worker': idx,
                        'phase': task['phase'],
                        'start': start_time,
                        'end': start_time + timedelta(hours=task['duration']),
                        'duration': task['duration'],
                        'deadline': task['deadline']
                    })
                    worker_times[idx] += task['duration']
                    assigned = True
                    break
            if not assigned:
                pass  # task skipped for now
    return workers_needed_per_month, schedule

# Gantt Chart

def plot_schedule(schedule):
    fig, ax = plt.subplots(figsize=(14, 8))
    colors = {'mbom': 'skyblue', 'workInstruction': 'lightgreen', 'routing': 'salmon'}
    yticks = []
    ytick_labels = []
    y = 0
    for ebom_id, phases in schedule.items():
        for task in phases:
            ax.barh(y, (task['end'] - task['start']).total_seconds() / 3600, left=task['start'], color=colors[task['phase']])
            ax.text(task['start'], y, f"{ebom_id}-{task['phase']} (W{task['worker']})", va='center', fontsize=8)
            yticks.append(y)
            ytick_labels.append(ebom_id)
            y += 1
    ax.set_yticks(yticks)
    ax.set_yticklabels(ytick_labels)
    ax.xaxis.set_major_locator(mdates.MonthLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
    plt.title("Worker Task Schedule Gantt Chart")
    plt.tight_layout()
    plt.show()

# Export to CSV

def export_schedule_to_csv(schedule, filename="logs\schedule_export.csv"):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file, delimiter=';')
        writer.writerow(["EBOM_ID", "Phase", "Worker", "Start", "End", "Duration", "Deadline"])
        for ebom_id, tasks in schedule.items():
            for task in tasks:
                writer.writerow([ebom_id, task['phase'], task['worker'], task['start'], task['end'], task['duration'], task['deadline']])

# Main execution
eboms = generate_random_eboms(20)
workers_by_month, schedule = schedule_eboms(eboms)
print("Workers Needed Per Month:")
for m, w in workers_by_month.items():
    print(f"Month {m}: {w} workers")

plot_schedule(schedule)
export_schedule_to_csv(schedule)
