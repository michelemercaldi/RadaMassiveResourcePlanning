import sys
import json
import plotly.graph_objects as go


# poetry env info -p
# C:\Users\m.mercaldi\radarepos\gurobi\.venv

# test link to actual gurobi
#  http://200.1.0.66:8000/docs



def visualize_from_file(filename: str):
    with open(filename, "r") as f:
        data = json.load(f)
    
    # Edge trace
    edge_x, edge_y = [], []
    for edge in data["edges"]:
        # Fetch source node coordinates
        source_node = next(node for node in data["nodes"] if node["id"] == edge["source"])
        x0, y0 = source_node["x"], source_node["y"]
        
        # Fetch target node coordinates
        target_node = next(node for node in data["nodes"] if node["id"] == edge["target"])
        x1, y1 = target_node["x"], target_node["y"]
        
        # Add edge coordinates
        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])
    
    edge_trace = go.Scatter(
        x=edge_x, y=edge_y,
        line=dict(width=0.5, color="#888"),
        hoverinfo="none",
        mode="lines"
    )
    
    # Node trace
    node_x = [node["x"] for node in data["nodes"]]
    node_y = [node["y"] for node in data["nodes"]]
    node_text = [node["id"] for node in data["nodes"]]
    
    node_trace = go.Scatter(
        x=node_x, y=node_y,
        mode="markers+text",
        text=node_text,
        textposition="bottom center",
        marker=dict(
            color="lightblue",
            size=15,
            line=dict(width=2, color="DarkSlateGrey")
        )
    )
    
    # Create figure
    fig = go.Figure(data=[edge_trace, node_trace])
    fig.update_layout(showlegend=False, hovermode="closest")
    fig.show()



if __name__ == "__main__":
    filepath = "logs\merged_graph_data_splitted_operations.json"
    if len(sys.argv) >= 2:
        filepath = str(sys.argv[1])
    visualize_from_file(filename=filepath)

