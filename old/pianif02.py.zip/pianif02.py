import random
from datetime import datetime, timedelta
from collections import defaultdict
import csv


# --- CONFIGURATION ---
NUM_EBOMS = 10
SHIFT_CONFIG = {
    1: {"start": "06:00", "duration": 7.5, "saturation": 0.9},
    2: {"start": "14:00", "duration": 7.5, "saturation": 0.9},
    3: {"start": "22:00", "duration": 7.0, "saturation": 0.9},
}
START_DATE = datetime(2024, 5, 1)
TICK = timedelta(minutes=10)
PLANNING_DAYS = 10   #elapsed
MAX_WORKERS = 5

# ---------------- HELPERS ---------------- #
def format_time(dt): return dt.strftime("%Y-%m-%d %H:%M")
def format_date(dt): return dt.strftime("%Y-%m-%d")
def format_time_only(dt): return dt.strftime("%H:%M")


# --- TEAR UP FUNCTIONS ---
def generate_shifts(start_date, days):
    shifts = []
    for day in range(days):
        day_base = start_date + timedelta(days=day)
        for shift_num, conf in SHIFT_CONFIG.items():
            t = datetime.strptime(conf["start"], "%H:%M")
            shift_start = day_base.replace(hour=t.hour, minute=t.minute)
            shift_end = shift_start + timedelta(hours=conf["duration"])
            shifts.append({
                "shift_num": shift_num,
                "start": shift_start,
                "end": shift_end,
                "duration": conf["duration"],
                "saturation": conf["saturation"],
                "min_required": conf["duration"] * conf["saturation"],
                "workers": defaultdict(list)  # worker_id → list of (start, end, task)
            })
    return shifts


def generate_eboms(n):
    eboms = []
    for i in range(n):
        base_start = START_DATE + timedelta(days=random.randint(0, 3))

        mbom_cost = round(random.uniform(3.0, 7.5), 1)
        wi_cost = round(random.uniform(3.0, 70.0), 1)
        routing_cost = round(random.uniform(3.0, 9.0), 1)
        
        mbom_deadline = base_start + timedelta(days=(mbom_cost/24 + 1))
        wi_deadline = mbom_deadline + timedelta(days=(wi_cost/24 + 1))
        routing_deadline = wi_deadline + timedelta(days=(routing_cost/24 + 1))

        eboms.append({
            "id": f"EBOM{i+1}",
            "eng_release_date": base_start,
            "phases": [
                {
                    "name": "mbom",
                    "deadline": mbom_deadline,
                    "cost": mbom_cost,
                    "remaining_cost": mbom_cost,
                    "active_worker": None
                },
                {
                    "name": "workinstruction",
                    "deadline": wi_deadline,
                    "cost": wi_cost,
                    "remaining_cost": wi_cost,
                    "active_worker": None
                },
                {
                    "name": "routing",
                    "deadline": routing_deadline,
                    "cost": routing_cost,
                    "remaining_cost": routing_cost,
                    "active_worker": None
                }
            ]
        })
    return eboms



# ---------------- PETRI NET SIMULATOR ---------------- #
class PetriNetSimulator:
    def __init__(self, eboms, shifts):
        self.eboms = eboms
        self.shifts = shifts
        self.current_time = START_DATE
        self.available_workers = [f"W{i+1}" for i in range(MAX_WORKERS)]
        self.in_progress = {}  # worker_id → {end, task}
        #self.tokens = [(ebom["id"], 0) for ebom in eboms]
        self.available_tasks = [(ebom["id"], 0) for ebom in eboms] # we start from phase 0
        self.completed = set()
        self.workers = {}
        self.schedule_log = []  # list of dicts for CSV/Gantt


    def run(self):
        end_time = START_DATE + timedelta(days=PLANNING_DAYS)
        print(f"\n\n🕒 Simulation starts: {format_time(self.current_time)}")
        print(f"🕒   expected end at: {format_time(end_time)}\n")

        while self.current_time <= end_time:
            #print(f"\n=== ⏱️ Time Tick: {format_time(self.current_time)} ===")
            self.print_shift_start_end(self.current_time)
            #self.debug_print_in_progress()
            
            if self.shift_start(self.current_time):
                self.workers.clear()
                for i in range(MAX_WORKERS):
                    self.workers[f"W{i+1}"] = {
                        "current_task": None,
                        "working_hours": 0
                    }

            for available_task in self.get_available_tasks():
                print(f"    🐞 available task: {available_task}")
            
            
            if self.shift_end(self.current_time):
                # check worker saturation
                pass
            
            self.current_time += TICK

        print(f"\n✅ Simulation ended at {format_time(self.current_time)}")
        print(f"👷 Workers Used: {MAX_WORKERS}")
        #print(f"🧮 Task Load: {sum(len(w) for s in self.shifts for w in s['workers'].values())} assignments")
        print(f"📦 Completed EBOMs: {len(self.completed)} / {len(self.eboms)}")
        #self.debug_print_remaining_tasks()


    def get_available_tasks(self):
        available_tasks = []
        for ebom in self.eboms:
            phase_added = False
            for phase_idx, phase in enumerate(ebom["phases"]):
                if not phase_added and phase["remaining_cost"] > 0 and self.current_time >= ebom["eng_release_date"]:
                    available_tasks.append((ebom["id"], phase))
                    phase_added = True
        return available_tasks

    # def run_old2(self):
    #     end_time = START_DATE + timedelta(days=PLANNING_DAYS)
    #     print(f"\n\n🕒 Simulation starts: {format_time(self.current_time)}")
    #     print(f"🕒   expected end at: {format_time(end_time)}\n")

    #     while self.current_time <= end_time and (self.available_tasks or self.in_progress):
    #         #print(f"\n=== ⏱️ Time Tick: {format_time(self.current_time)} ===")
    #         self.print_shift_start_end(self.current_time)
    #         #self.debug_print_in_progress()
            
    #         # 1. Release workers who completed tasks
    #         for wid, task_in_progress in list(self.in_progress.items()):
    #             if self.current_time >= task_in_progress["end"]:
    #                 print(f"🔁 {wid} finished {task_in_progress['task']} at {format_time(self.current_time)}")
    #                 self.available_workers.append(wid)
    #                 del self.in_progress[wid]
    #                 self.debug_print_in_progress()

    #         # 2. Try assigning available workers to tasks
    #         new_available_tasks = []
    #         for available_task in self.available_tasks:
    #             if not self.available_workers:
    #                 break  # wait for free worker

    #             ebom_id, phase_idx = available_task
    #             ebom = next(e for e in self.eboms if e["id"] == ebom_id)
    #             phase = ebom["phases"][phase_idx]
    #             task_id = f"{ebom_id}.{phase['name']}"

    #             if self.current_time < ebom["eng_release_date"]:
    #                 # EBOM not released yet
    #                 new_available_tasks.append(available_task)
    #                 continue

    #             shift = self.find_shift_allow_partial(self.current_time, phase["deadline"])
    #             if not shift:
    #                 new_available_tasks.append(available_task)
    #                 continue

    #             # Assign worker
    #             wid = self.available_workers.pop(0)
    #             start = self.current_time

    #             # how many hours are left in the current shift from now until the shift ends
    #             available_time = (shift["end"] - self.current_time).total_seconds() / 3600
    #             assignable = min(available_time, phase["remaining_cost"])

    #             end = start + timedelta(hours=assignable)
    #             phase["remaining_cost"] -= assignable
    #             shift["workers"][wid].append((start, end, task_id))
    #             self.in_progress[wid] = {"end": end, "task": task_id}

    #             print(f"✔️ {task_id} assigned to {wid} | {format_time(start)} → {format_time(end)} (Shift {shift['shift_num']})")
    #             self.debug_print_in_progress()

    #             # log for csv * gantt
    #             self.schedule_log.append({
    #                 "worker": wid,
    #                 "task": task_id,
    #                 "ebom": ebom_id,
    #                 "phase": phase['name'],
    #                 "start": start,
    #                 "end": end,
    #                 "shift": shift["shift_num"]
    #             })

    #             # Advance token to next phase or mark EBOM done
    #             if phase["remaining_cost"] > 0:
    #                 # Same phase still has work left
    #                 new_available_tasks.append((ebom_id, phase_idx))
    #             else:
    #                 # Phase complete, move on
    #                 if phase_idx < 2:
    #                     new_available_tasks.append((ebom_id, phase_idx + 1))
    #                 else:
    #                     self.completed.add(ebom_id)
                        
    #         self.available_tasks = new_available_tasks
    #         self.current_time += TICK
            
    #     print(f"    🐞 available tasks: {len(self.available_tasks)}")
    #     print(f"    🐞 in progress tasks: {len(self.available_tasks)}")

    #     print(f"\n✅ Simulation ended at {format_time(self.current_time)}")
    #     print(f"👷 Workers Used: {MAX_WORKERS}")
    #     #print(f"🧮 Task Load: {sum(len(w) for s in self.shifts for w in s['workers'].values())} assignments")
    #     print(f"📦 Completed EBOMs: {len(self.completed)} / {len(self.eboms)}")
    #     self.debug_print_remaining_tasks()


    # def run_old(self):
    #     end_time = START_DATE + timedelta(days=PLANNING_DAYS)
    #     print(f"\n\n🕒 Simulation starts: {format_time(self.current_time)}\n")

    #     while self.current_time <= end_time and (self.tokens or self.in_progress):
    #         #print(f"\n=== ⏱️ Time Tick: {format_time(self.current_time)} ===")
    #         self.print_shift_start_end(self.current_time)
    #         #self.debug_print_in_progress()

    #         # 1. Release workers who completed tasks
    #         for wid, task_in_progress in list(self.in_progress.items()):
    #             if self.current_time >= task_in_progress["end"]:
    #                 print(f"🔁 {wid} finished {task_in_progress['task']} at {format_time(self.current_time)}")
    #                 self.available_workers.append(wid)
    #                 del self.in_progress[wid]
    #                 self.debug_print_in_progress()

    #         # 2. Try assigning available workers to tasks
    #         new_tokens = []
    #         for token in self.tokens:
    #             if not self.available_workers:
    #                 break  # wait for free worker

    #             ebom_id, phase_idx = token
    #             ebom = next(e for e in self.eboms if e["id"] == ebom_id)
    #             phase = ebom["phases"][phase_idx]
    #             task_id = f"{ebom_id}.{phase['name']}"

    #             if self.current_time < ebom["eng_release_date"] or phase_idx > 0:
    #                 new_tokens.append(token)
    #                 continue

    #             shift = self.find_shift_allow_partial(self.current_time, phase["deadline"])
    #             if not shift:
    #                 new_tokens.append(token)
    #                 continue

    #             # Assign worker
    #             wid = self.available_workers.pop(0)
    #             start = self.current_time

    #             # how many hours are left in the current shift from now until the shift ends
    #             available_time = (shift["end"] - self.current_time).total_seconds() / 3600
    #             assignable = min(available_time, phase["remaining_cost"])

    #             end = start + timedelta(hours=assignable)
    #             phase["remaining_cost"] -= assignable
    #             shift["workers"][wid].append((start, end, task_id))
    #             self.in_progress[wid] = {"end": end, "task": task_id}

    #             print(f"✔️ {task_id} assigned to {wid} | {format_time(start)} → {format_time(end)} (Shift {shift['shift_num']})")
    #             self.debug_print_in_progress()

    #             # log for csv * gantt
    #             self.schedule_log.append({
    #                 "worker": wid,
    #                 "task": task_id,
    #                 "ebom": ebom_id,
    #                 "phase": phase['name'],
    #                 "start": start,
    #                 "end": end,
    #                 "shift": shift["shift_num"]
    #             })

    #             # Advance token to next phase or mark EBOM done
    #             if phase["remaining_cost"] > 0:
    #                 # Same phase still has work left
    #                 new_tokens.append((ebom_id, phase_idx))
    #             else:
    #                 # Phase complete, move on
    #                 if phase_idx < 2:
    #                     new_tokens.append((ebom_id, phase_idx + 1))
    #                 else:
    #                     self.completed.add(ebom_id)

    #         self.tokens = new_tokens
    #         self.current_time += TICK

    #     print(f"\n✅ Simulation ended at {format_time(self.current_time)}")
    #     print(f"👷 Workers Used: {MAX_WORKERS}")
    #     #print(f"🧮 Task Load: {sum(len(w) for s in self.shifts for w in s['workers'].values())} assignments")
    #     print(f"📦 Completed EBOMs: {len(self.completed)} / {len(self.eboms)}")
    #     self.debug_print_remaining_tokens()


    def find_shift_allow_partial(self, now, deadline):
        for shift in self.shifts:
            if shift["start"] <= now < shift["end"]:
                if now < deadline:
                    return shift
        return None

    
    def shift_start(self, curtime):
        for shift in self.shifts:
            if shift["start"] == curtime:
                print("--------------------------------")
                print(f"🕒 {format_date(shift['start'])} - Shift {shift['shift_num']} started: {format_time_only(shift['start'])} - {format_time_only(shift['end'])}")
                return True
        return False

    def shift_end(self, curtime):
        for shift in self.shifts:
            if shift["end"] == curtime:
                print(f"🕒 {format_date(shift['end'])} - Shift {shift['shift_num']} end at {format_time_only(shift['end'])}")
                return True
        return False


    def print_shift_start_end(self, curtime):
        for shift in self.shifts:
            if shift["start"] == curtime:
                print("--------------------------------")
                print(f"🕒 {format_date(shift['start'])} - Shift {shift['shift_num']} started: {format_time_only(shift['start'])} - {format_time_only(shift['end'])}")
                #self.debug_print_in_progress()
            if shift["end"] == curtime:
                print(f"🕒 {format_date(shift['end'])} - Shift {shift['shift_num']} end at {format_time_only(shift['end'])}")


    def debug_print_in_progress(self):
        print(f"    🐞 {format_time(self.current_time)}:")
        for wid, task in self.in_progress.items():
            remaining_time = (task['end'] - self.current_time).total_seconds() / 3600
            print(f"    🐞    {wid} on {task['task']} still for {remaining_time:.2f}h")


    def debug_print_remaining_tasks(self):
        print(f"    🐞 Remaining tasks:")
        for ebom in eboms:
            for phase in ebom["phases"]:
                if phase["remaining_cost"] > 0:
                    print(f"    🐞    {ebom['id']}.{phase['name']} : remaining cost: {phase['remaining_cost']}")


    def debug_print_remaining_tokens(self):
        print(f"    🐞 Remaining tokens:")
        for ebom_id, phase_idx in self.tokens:
            ebom = next(e for e in self.eboms if e["id"] == ebom_id)
            phase = ebom["phases"][phase_idx]
            print(f"    🐞    {ebom_id} - {phase['name']} (remaining: {phase['remaining_cost']})")



# ---------------- MAIN ENTRY ---------------- #
if __name__ == "__main__":
    goon = True
    shifts = generate_shifts(START_DATE, PLANNING_DAYS)
    print("🛠️ Shifts Generated:")
    for shift in shifts:
        print(f"  📆 {format_time(shift['start'])} - Shift {shift['shift_num']} (Duration: {shift['duration']}h, Min Required: {shift['min_required']}h)")
    if not goon: exit()

    eboms = generate_eboms(NUM_EBOMS)
    print("\n📋 EBOMs Generated:")
    for ebom in eboms:
        print(f"  🏷️ {ebom['id']}  -  eng. release: {format_date(ebom['eng_release_date'])}")
        for phase in ebom["phases"]:
            print(f"    - {phase['name']} (Deadline: {format_date(phase['deadline'])}), Cost: {phase['cost']}h")
    if not goon: exit()

    sim = PetriNetSimulator(eboms, shifts)
    sim.run()

    export_file = "logs\massive_planning_schedule_export.csv"
    with open(export_file, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["worker", "task", "ebom", "phase", "start", "end", "shift"], delimiter=';')
        writer.writeheader()
        for row in sim.schedule_log:
            writer.writerow({**row, "start": format_time(row["start"]), "end": format_time(row["end"])})
    print(f"✅ CSV exported: {export_file}")



