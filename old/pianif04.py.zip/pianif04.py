import random
from datetime import datetime, timedelta
from collections import defaultdict
import csv


# --- CONFIGURATION ---
NUM_EBOMS = 10
SHIFT_CONFIG = {
    1: {"start": "06:00", "duration": 7.5, "saturation": 0.9},
    2: {"start": "14:00", "duration": 7.5, "saturation": 0.9},
    #3: {"start": "22:00", "duration": 7.0, "saturation": 0.9},
}
START_DATE = datetime(2024, 5, 1)
TICK = timedelta(minutes=10)
PLANNING_DAYS = 25 * 15   #elapsed
MAX_WORKERS = 5

MONTHS_GAP_AFTER_MBOM = 5  # Enforce gap after mbom

# ---------------- HELPERS ---------------- #
def format_time(dt): return dt.strftime("%Y-%m-%d %H:%M")
def format_date(dt): return dt.strftime("%Y-%m-%d")
def format_time_only(dt): return dt.strftime("%H:%M")


# --- TEAR UP FUNCTIONS ---
def generate_shifts(start_date, days):
    shifts = []
    for day in range(days):
        day_base = start_date + timedelta(days=day)
        for shift_num, conf in SHIFT_CONFIG.items():
            t = datetime.strptime(conf["start"], "%H:%M")
            shift_start = day_base.replace(hour=t.hour, minute=t.minute)
            shift_end = shift_start + timedelta(hours=conf["duration"])
            shifts.append({
                "shift_num": shift_num,
                "start": shift_start,
                "end": shift_end,
                "duration": conf["duration"],
                "saturation": conf["saturation"],
                "min_required": conf["duration"] * conf["saturation"],
                "workers": defaultdict(list)  # worker_id → list of (start, end, task)
            })
    return shifts


def generate_eboms(n):
    eboms = []
    for i in range(n):
        base_start = START_DATE + timedelta(days=random.randint(0, 3))

        mbom_cost = round(random.uniform(3.0, 7.5), 1)
        wi_cost = round(random.uniform(3.0, 70.0), 1)
        routing_cost = round(random.uniform(3.0, 9.0), 1)
        
        mbom_deadline = base_start + timedelta(days=(mbom_cost/24 + 1))
        wi_deadline = base_start + timedelta(PLANNING_DAYS) - timedelta(days=(wi_cost/24 + 1))
        routing_deadline = base_start + timedelta(PLANNING_DAYS) - timedelta(days=(routing_cost/24 + 1))
        
        eboms.append({
            "id": f"EBOM{i+1}",
            "eng_release_date": base_start,
            "phases": [
                {
                    "id": 0,
                    "name": "mbom",
                    "deadline": mbom_deadline,
                    "cost": mbom_cost,
                    "remaining_cost": mbom_cost,
                    "active_worker": None
                },
                {
                    "id": 1,
                    "name": "workinstruction",
                    "deadline": wi_deadline,
                    "cost": wi_cost,
                    "remaining_cost": wi_cost,
                    "active_worker": None
                },
                {
                    "id": 2,
                    "name": "routing",
                    "deadline": routing_deadline,
                    "cost": routing_cost,
                    "remaining_cost": routing_cost,
                    "active_worker": None
                }
            ]
        })
    return eboms




# ---------------- PETRI NET SIMULATOR ---------------- #
class PetriNetSimulator:
    def __init__(self, eboms, shifts):
        self.eboms = eboms
        self.shifts = shifts
        self.current_time = START_DATE
        self.available_workers = [f"W{i+1}" for i in range(MAX_WORKERS)]
        self.in_progress = {}  # worker_id → {end, task}
        #self.tokens = [(ebom["id"], 0) for ebom in eboms]
        self.available_tasks = [(ebom["id"], 0) for ebom in eboms] # we start from phase 0
        self.workers = {}
        # start date for workinstrunction and routing will be delayed based on the MONTHS_GAP_AFTER_MBOM
        self.start_date_for_production_phases = self.get_max_mbom_deadline() + timedelta(days=MONTHS_GAP_AFTER_MBOM)
        self.schedule_log = []  # list of dicts for CSV/Gantt


    def run(self):
        end_time = START_DATE + timedelta(days=PLANNING_DAYS)
        print(f"\n\n🕒 Simulation starts: {format_time(self.current_time)}")
        print(f"🕒   expected end at: {format_time(end_time)}\n")

        is_working_time = False
        current_shift_num = -1

        while self.current_time <= end_time:
            #print(f"\n=== ⏱️ Time Tick: {format_time(self.current_time)} ===")
            htick = TICK.total_seconds() / 3600  # Convert TICK to hours

            is_starting, shift_num = self.is_shift_start(self.current_time)
            if is_starting:
                # _mme shiftlog print("--------------------------------")
                # _mme shiftlog print(f"🕒 {format_date(self.current_time)} - Shift {shift_num} start at {format_time_only(self.current_time)}")
                self.workers = self.reset_workers()
                is_working_time = True
                current_shift_num = shift_num

            if is_working_time:
                #print(" _mme available   ", [f"{ebomid}.{task['name']}" for ebomid, task in self.get_available_tasks()])
                for ebomid, task in self.get_available_tasks():
                    worker_id_on_closed_task = None
                    #if task['active_worker'] is not None:
                    #    print(f"    🐞 task: {ebomid}.{task['name']}, active_worker:{task['active_worker']}, remaining_cost:{task['remaining_cost']:.1f}")

                    # check if this task is currently in progress
                    if task['active_worker'] is not None and task['remaining_cost'] > 0:
                        # decrease remaining cost for this task
                        task['remaining_cost'] -= htick
                        # increase working time for the worker
                        self.workers[task['active_worker']]['working_hours'] += htick
                    
                    # check if we can close this task
                    if task['active_worker'] is not None and task['remaining_cost'] <= 0:
                        print(f"    🛬 task: {ebomid}.{task['name']} completed by {task['active_worker']} at {format_time(self.current_time + TICK)}")
                        # finalize this task
                        self.schedule_log_append(ebomid, task, current_shift_num)
                        worker_id_on_closed_task = task['active_worker']
                        self.workers[task['active_worker']]['current_task'] = None
                        task['active_worker'] = None

                        # todo: check if this token is closed before the deadline

                        # get next task in this ebom
                        ebom = next(e for e in self.eboms if e["id"] == ebomid)
                        if len(ebom['phases']) > (task['id'] + 1):
                            task = ebom['phases'][task['id'] + 1]
                        else:
                            task = None

                    # check if we can assign the task to a worker
                    # if self.current_time > self.start_date_for_production_phases: print(f" _mme canbe ass: {self.task_can_be_assigned(task)}")
                    if self.task_can_be_assigned(task):
                        worker_id = self.get_first_available_worker_with_max_capacity(not_the_worker = worker_id_on_closed_task)
                        if worker_id is not None:
                            # assign this task to a worker
                            task['remaining_cost'] -= htick
                            task['active_worker'] = worker_id
                            self.workers[worker_id]['current_task'] = f"{ebomid}.{task['name']}"
                            self.workers[worker_id]['current_task_start'] = self.current_time
                            self.workers[worker_id]['working_hours'] += htick
                            print(f"    👷 task: {ebomid}.{task['name']} assigned to {task['active_worker']} at {format_time(self.current_time)}")
            
            is_ending, shift_num = self.is_shift_end(self.current_time)
            if is_ending:
                # _mme shiftlog print(f"🕒 {format_date(self.current_time)} - Shift {shift_num} end at  {format_time_only(self.current_time)}")
                # todo: check worker saturation
                # close shift, reset assignments
                self.reset_eboms_assignement_to_workers()
                # log all workers, they will be reassigned in the next shift
                for ebomid, task in self.get_available_tasks():
                    self.schedule_log_append(ebomid, task, current_shift_num)
                is_working_time = False
                current_shift_num = -1

            self.current_time += TICK

        print(f"\n✅ Simulation ended at {format_time(self.current_time)}")
        print(f"👷 Workers Used: {MAX_WORKERS}")

        uncompleted_eboms = self.get_uncompleted_eboms()
        if uncompleted_eboms:
            print(f"⚠️ Uncompleted EBOMs: {len(uncompleted_eboms)}")
            self.print_remaining_tasks()
        else:
            print("📦 All EBOMs completed!")


    def task_can_be_assigned(self, task):
        if task is None:
            return False
        #if task['name'] == "workinstruction": print(f" _mme task_can_be_assigned: {task}")
        # check if this task is already assigned to a worker
        if task['active_worker'] is not None:
            return False

        # check if this task is already completed
        if task['remaining_cost'] <= 0:
            return False

        # check if this task is not mbom and it is in the future
        if task['name'] != "mbom" and self.current_time < self.start_date_for_production_phases:
            return False
        
        if self.current_time > task["deadline"]:
            return False

        return True

    def get_max_mbom_deadline(self):
        max_deadline = datetime(1971, 1, 1)
        for ebom in self.eboms:
            if ebom["phases"][0]["deadline"] > max_deadline:
                max_deadline = ebom["phases"][0]["deadline"]
        return max_deadline

    def schedule_log_append(self, ebomid, task, shift_num):
        # log for csv * gantt
        if task['active_worker'] != None:
            self.schedule_log.append({
                "worker": task['active_worker'],
                "task": f"{ebomid}.{task['name']}",
                "shift": shift_num,
                "start": self.workers[task['active_worker']]['current_task_start'],
                "end": self.current_time
            })

    def reset_workers(self):
        workers = {}
        for i in range(MAX_WORKERS):
            workers[f"W{i+1}"] = {
                "id": f"W{i+1}",
                "current_task": None,
                "current_task_start": None,
                "working_hours": 0
            }
        return workers

    def reset_eboms_assignement_to_workers(self):
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                phase["active_worker"] = None
        self.available_tasks = [(ebom["id"], 0) for ebom in self.eboms]
            
    def get_available_tasks(self):
        available_tasks = []
        for ebom in self.eboms:
            phase_added = False
            for phase_idx, phase in enumerate(ebom["phases"]):
                if not phase_added and phase["remaining_cost"] > 0 and self.current_time >= ebom["eng_release_date"]:
                    available_tasks.append((ebom["id"], phase))
                    phase_added = True
        return available_tasks

    def get_first_available_worker_with_max_capacity(self, not_the_worker=None):
        # todo : get worker with max available capacity
        workers = [f"W{i+1}" for i in range(MAX_WORKERS)]
        for ebom in self.eboms:
            for phase_idx, phase in enumerate(ebom["phases"]):
                if phase['active_worker'] is not None:
                    workers.remove(phase['active_worker'])
        if not_the_worker in workers:
            workers.remove(not_the_worker)
        if len(workers) > 0:
            # return worker that has the least working hours
            return min(workers, key=lambda w: self.workers[w]['working_hours'])
        return None

    def get_first_available_worker(self, not_the_worker=None):
        # todo : get worker with max available capacity
        workers = [f"W{i+1}" for i in range(MAX_WORKERS)]
        for ebom in self.eboms:
            for phase_idx, phase in enumerate(ebom["phases"]):
                if phase['active_worker'] is not None:
                    workers.remove(phase['active_worker'])
        if not_the_worker in workers:
            workers.remove(not_the_worker)
        if len(workers) > 0:
            return workers[0]
        return None

    def get_uncompleted_eboms(self):
        unceboms = set()
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                if phase["remaining_cost"] > 0:
                    unceboms.add(ebom["id"])
                    break
        return [ebom for ebom in self.eboms if ebom["id"] in unceboms]

    def get_uncompleted_mboms(self):
        uncmboms = set()
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                if phase["name"] == "mbom" and phase["remaining_cost"] > 0:
                    uncmboms.add(ebom["id"])
                    break
        return [ebom for ebom in self.eboms if ebom["id"] in uncmboms]

    def is_shift_start(self, curtime):
        for shift in self.shifts:
            if shift["start"] == curtime:
                # shift cannot start if all mbom are completed and we are behind the production date start
                if len(self.get_uncompleted_mboms()) == 0 and self.current_time < self.start_date_for_production_phases:
                    #print(f'_mme  {self.current_time} no for {self.start_date_for_production_phases}')
                    return False, -1
                return True, shift["shift_num"]
        return False, -1

    def is_shift_end(self, curtime):
        for shift in self.shifts:
            if shift["end"] == curtime:
                return True, shift["shift_num"]
        return False, -1

    def print_remaining_tasks(self):
        print(f"    🐞 Remaining tasks:")
        for ebom in eboms:
            for phase in ebom["phases"]:
                if phase["remaining_cost"] > 0:
                    print(f"    🐞    {ebom['id']}.{phase['name']} : remaining cost: {phase['remaining_cost']:.1f}")




# ---------------- MAIN ENTRY ---------------- #
if __name__ == "__main__":
    goon = True
    shifts = generate_shifts(START_DATE, PLANNING_DAYS)
    print("🛠️ Shifts Generated:")
    for shift in shifts:
        print(f"  📆 {format_time(shift['start'])} - Shift {shift['shift_num']} (Duration: {shift['duration']}h, Min Required: {shift['min_required']}h)")
    if not goon: exit()

    eboms = generate_eboms(NUM_EBOMS)
    print("\n📋 EBOMs Generated:")
    for ebom in eboms:
        print(f"  🏷️ {ebom['id']}  -  eng. release: {format_date(ebom['eng_release_date'])}")
        for phase in ebom["phases"]:
            print(f"    - {phase['name']} (Deadline: {format_date(phase['deadline'])}), Cost: {phase['cost']}h")
    if not goon: exit()

    sim = PetriNetSimulator(eboms, shifts)
    sim.run()

    export_file = "logs\massive_planning_schedule_export.csv"
    with open(export_file, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["worker", "task", "start", "end", "shift"], delimiter=';')
        writer.writeheader()
        for row in sim.schedule_log:
            writer.writerow({**row, "start": format_time(row["start"]), "end": format_time(row["end"])})
    print(f"✅ CSV exported: {export_file}")

 