import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
from datetime import datetime

def plot_gantt_from_csv(csv_path):
    # Load CSV
    df = pd.read_csv(csv_path, delimiter=';')
    df["start"] = pd.to_datetime(df["start"])
    df["end"] = pd.to_datetime(df["end"])
    df.sort_values(by=["worker", "start"], inplace=True)

    # Setup canvas
    fig, ax = plt.subplots(figsize=(16, 10))
    workers = df["worker"].unique()
    cmap = plt.cm.get_cmap("tab20", len(workers))
    worker_indices = {worker: i for i, worker in enumerate(workers)}

    yticks = list(range(len(workers)))
    ylabels = workers

    for _, row in df.iterrows():
        worker = row["worker"]
        task = f"{row['ebom']}.{row['phase']}"
        idx = worker_indices[worker]
        start = row["start"]
        end = row["end"]
        duration = end - start

        ax.barh(
            y=idx,
            left=start,
            width=duration,
            height=0.4,
            color=cmap(idx),
            edgecolor="black"
        )

        ax.text(
            start + duration / 2,
            idx,
            task,
            ha="center",
            va="center",
            fontsize=8,
            color="white"
        )

    # Format axis
    ax.set_yticks(yticks)
    ax.set_yticklabels(ylabels)
    ax.set_xlabel("Time")
    ax.set_title("👷 Worker Schedule Gantt Chart (Split Task Support)")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
    ax.grid(True, axis="x", linestyle="--", alpha=0.5)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    plot_gantt_from_csv("logs/massive_planning_schedule_export.csv")
