import os
import random
from datetime import datetime, timedelta
from collections import defaultdict
import csv
import logging
import math
import sys


# ---------------- CONFIGURATION ---------------- #

# --------- USER INPUT --------- #
ID_PROGETTO = 71
SHIFT_CONFIG = {
    1: {"start": "06:00", "duration": 7.5},
    2: {"start": "14:00", "duration": 7.5},
    #3: {"start": "22:00", "duration": 7.0},
}
TICK = timedelta(minutes=30)

# data inizio produzione per ogni cassa
#  list of casse from database
casse_production_dates = {
    '4A1': '2025-09-23',
    '4A2': '2025-10-23',
    '4A3': '2025-11-23',
    '4A4': '2025-12-23'
}

multiplier_ebom_to_dtr = 3  # ---- this is the conversion factor from EBOM to DRT, default = 3
 
# ---- hourly unit cost for MBOM, WORK INSTRUCTION, ROUTING
#  default values from database, but can be modified
class HourlyUnitCosts:
    mbom = 1                # M-BOM cost
    workinstruction = 40    # WORK INSTRUCTION cost
    routing = 2             # ROUTING cost

GAP_AFTER_MBOM_IN_DAYS = 0  # Enforce gap after mbom




# --------- FROM DATABASE --------- #
NUM_EBOMS = 15
#  list of eboms generated from database and user input
class DeadlineOffset:
    mbom = 10              # M-BOM deadline offset in days
    workinstruction = -20  # WORK INSTRUCTION deadline offset in days
    routing = -5           # ROUTING deadline offset in days




# ---------------- CONFIGURATION END ---------------- #




# ---------------- HELPERS ---------------- #
global_logger = None
def format_time(dt): return dt.strftime("%Y-%m-%d %H:%M")
def format_date(dt): return dt.strftime("%Y-%m-%d")
def format_time_only(dt): return dt.strftime("%H:%M")
def setup_logger(log_file):
    global global_logger
    # Create a logger
    logger = logging.getLogger('pianif_logger')
    logger.setLevel(logging.DEBUG)  # Set the logging level to DEBUG to capture all logs

    # Remove any existing handlers (to avoid duplicate logs if setup_logger is called multiple times)
    if logger.hasHandlers():
        logger.handlers.clear()

    # Create a file handler with utf-8 encoding (DEBUG level)
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)

    # Create a console handler (INFO level)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    # Formatter
    formatter = logging.Formatter('%(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # Add handlers
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    global_logger = logger
    return logger

def log_ext(message):
    if global_logger is not None:
        global_logger.info(message)
    else:
        print(message)

def log_ext_debug(message):
    if global_logger is not None:
        # Only log to file, not to console
        # Use a custom logger with only the file handler, or filter in the handler
        # But since both handlers are attached, and console is INFO, DEBUG will not show on console
        global_logger.debug(message)
    else:
        # Optionally, do nothing or print
        pass



# --- TEAR UP FUNCTIONS ---
def get_month_list(start_date, elapsed_days):
    """
    Returns a list of (year, month) tuples covering the period from start_date for elapsed_days.
    """
    months = []
    current = start_date.replace(day=1)
    end_date = start_date + timedelta(days=elapsed_days)
    while current < end_date:
        months.append((current.year, current.month))
        # Move to the first day of the next month
        if current.month == 12:
            current = current.replace(year=current.year + 1, month=1)
        else:
            current = current.replace(month=current.month + 1)
    return months


def generate_shifts(start_date, days, months):
    shifts = []
    for day in range(days):
        day_base = start_date + timedelta(days=day)
        for shift_num, conf in SHIFT_CONFIG.items():
            t = datetime.strptime(conf["start"], "%H:%M")
            shift_start = day_base.replace(hour=t.hour, minute=t.minute)
            shift_end = shift_start + timedelta(hours=conf["duration"])
            shifts.append({
                "shift_num": shift_num,
                "start": shift_start,
                "end": shift_end,
                "duration": conf["duration"],
                "shift_workers": []  # list of worker_id
            })
    return shifts


def generate_eboms(n):
    #eboms = generate_eboms_random(n)
    eboms = generate_eboms_fixed(n)
    return eboms

def generate_eboms_random(n):
    eboms = []
    daily_working_hours = sum(shift["duration"] for shift in SHIFT_CONFIG.values())  # total working hours in a day
    for i in range(n):
        sample_START_DATE = datetime(2024, 5, 1)
        base_start = sample_START_DATE + timedelta(days=random.randint(0, 3))

        mbom_cost = round(random.uniform(30.0, 75), 1)
        wi_cost = round(random.uniform(30, 70), 1)
        routing_cost = round(random.uniform(30, 90), 1)

        # we add 1 to to cover the partial day of work, +2 to be more on the safe side 
        mbom_deadline = base_start + timedelta(days=(int(mbom_cost // daily_working_hours + 2)))
        wi_deadline = base_start + timedelta(ELAPSED_DAYS) - timedelta(days=(int(wi_cost // daily_working_hours + 2)))
        routing_deadline = wi_deadline + timedelta(ELAPSED_DAYS) - timedelta(days=(int(routing_cost // daily_working_hours + 2)))
        
        eboms.append({
            "id": f"EBOM{i+1}",
            "eng_release_date": base_start,
            "phases": [
                {
                    "id": 0,
                    "name": "mbom",
                    "deadline": mbom_deadline,
                    "cost": mbom_cost,
                    "remaining_cost": mbom_cost,
                    "active_worker": None
                },
                {
                    "id": 1,
                    "name": "workinstruction",
                    "deadline": wi_deadline,
                    "cost": wi_cost,
                    "remaining_cost": wi_cost,
                    "active_worker": None
                },
                {
                    "id": 2,
                    "name": "routing",
                    "deadline": routing_deadline,
                    "cost": routing_cost,
                    "remaining_cost": routing_cost,
                    "active_worker": None
                }
            ]
        })
    return eboms

def generate_eboms_fixed(n):
    if n != 15:
        raise ValueError("generate_eboms_fixed: Only n=15 is supported for fixed EBOMs.")
        sys.exit()
    # Fixed EBOM data
    eboms = [
        {
            "id": "EBOM1",
            "eng_release_date": datetime(2024, 5, 2),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 8), "cost": 45.2, "remaining_cost": 45.2, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 18), "cost": 48.1, "remaining_cost": 48.1, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 6, 2), "cost": 36.5, "remaining_cost": 36.5, "active_worker": None}
            ]
        },
        {
            "id": "EBOM2",
            "eng_release_date": datetime(2024, 5, 3),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 9), "cost": 58.5, "remaining_cost": 58.5, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 19), "cost": 45.4, "remaining_cost": 45.4, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 6, 1), "cost": 64.0, "remaining_cost": 64.0, "active_worker": None}
            ]
        },
        {
            "id": "EBOM3",
            "eng_release_date": datetime(2024, 5, 1),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 8), "cost": 65.9, "remaining_cost": 65.9, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 18), "cost": 36.5, "remaining_cost": 36.5, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 5, 31), "cost": 70.2, "remaining_cost": 70.2, "active_worker": None}
            ]
        },
        {
            "id": "EBOM4",
            "eng_release_date": datetime(2024, 5, 1),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 7), "cost": 48.5, "remaining_cost": 48.5, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 18), "cost": 32.6, "remaining_cost": 32.6, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 5, 30), "cost": 77.7, "remaining_cost": 77.7, "active_worker": None}
            ]
        },
        {
            "id": "EBOM5",
            "eng_release_date": datetime(2024, 5, 3),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 7), "cost": 37.9, "remaining_cost": 37.9, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 16), "cost": 48.7, "remaining_cost": 48.7, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 5, 30), "cost": 50.7, "remaining_cost": 50.7, "active_worker": None}
            ]
        },
        {
            "id": "EBOM6",
            "eng_release_date": datetime(2024, 5, 4),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 8), "cost": 55.1, "remaining_cost": 55.1, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 19), "cost": 41.3, "remaining_cost": 41.3, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 6, 2), "cost": 48.6, "remaining_cost": 48.6, "active_worker": None}
            ]
        },
        {
            "id": "EBOM7",
            "eng_release_date": datetime(2024, 5, 2),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 6), "cost": 35.2, "remaining_cost": 35.2, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 17), "cost": 57.9, "remaining_cost": 57.9, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 6, 1), "cost": 32.7, "remaining_cost": 32.7, "active_worker": None}
            ]
        },
        {
            "id": "EBOM8",
            "eng_release_date": datetime(2024, 5, 1),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 8), "cost": 33.4, "remaining_cost": 33.4, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 18), "cost": 64.6, "remaining_cost": 64.6, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 6, 2), "cost": 42.9, "remaining_cost": 42.9, "active_worker": None}
            ]
        },
        {
            "id": "EBOM9",
            "eng_release_date": datetime(2024, 5, 2),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 7), "cost": 39.5, "remaining_cost": 39.5, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 17), "cost": 50.5, "remaining_cost": 50.5, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 5, 30), "cost": 71.8, "remaining_cost": 71.8, "active_worker": None}
            ]
        },
        {
            "id": "EBOM10",
            "eng_release_date": datetime(2024, 5, 2),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 8), "cost": 6.6, "remaining_cost": 6.6, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 18), "cost": 39.6, "remaining_cost": 39.6, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 6, 2), "cost": 42.8, "remaining_cost": 42.8, "active_worker": None}
            ]
        },
        {
            "id": "EBOM11",
            "eng_release_date": datetime(2024, 5, 1),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 7), "cost": 30.7, "remaining_cost": 30.7, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 18), "cost": 57.0, "remaining_cost": 57.0, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 5, 30), "cost": 78.2, "remaining_cost": 78.2, "active_worker": None}
            ]
        },
        {
            "id": "EBOM12",
            "eng_release_date": datetime(2024, 5, 2),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 10), "cost": 69.4, "remaining_cost": 69.4, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 18), "cost": 61.6, "remaining_cost": 61.6, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 6, 2), "cost": 36.2, "remaining_cost": 36.2, "active_worker": None}
            ]
        },
        {
            "id": "EBOM13",
            "eng_release_date": datetime(2024, 5, 3),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 6), "cost": 32.4, "remaining_cost": 32.4, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 16), "cost": 45.4, "remaining_cost": 45.4, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 5, 31), "cost": 33.1, "remaining_cost": 33.1, "active_worker": None}
            ]
        },
        {
            "id": "EBOM14",
            "eng_release_date": datetime(2024, 5, 4),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 8), "cost": 53.1, "remaining_cost": 53.1, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 17), "cost": 48.2, "remaining_cost": 48.2, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 6, 1), "cost": 34.8, "remaining_cost": 34.8, "active_worker": None}
            ]
        },
        {
            "id": "EBOM15",
            "eng_release_date": datetime(2024, 5, 1),
            "phases": [
                {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 10), "cost": 71.2, "remaining_cost": 71.2, "active_worker": None},
                {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 19), "cost": 53.0, "remaining_cost": 53.0, "active_worker": None},
                {"id": 0, "name": "routing", "deadline": datetime(2028, 6, 3), "cost": 32.2, "remaining_cost": 32.2, "active_worker": None}
            ]
        }
    ]

    return eboms


def get_min_eng_release_date(eboms):
    """
    Returns the minimum eng_release_date among all EBOMs.
    """
    return min(ebom["eng_release_date"] for ebom in eboms)


def get_min_cassa_production_date(casse_dates):
    """
    Returns the minimum production date from the casse_production_dates dictionary.
    """
    return min(datetime.strptime(date_str, "%Y-%m-%d") for date_str in casse_dates.values())



# ---------------- PETRI NET SIMULATOR ---------------- #
class PetriNetSimulator:
    def __init__(self, eboms, shifts, monthly_workers):
        self.eboms = eboms
        self.shifts = shifts
        self.monthly_workers = monthly_workers  # (year, month) → num_of_workers
        self.current_time = START_DATE
        self.available_tasks = [(ebom["id"], 0) for ebom in eboms] # we start from phase 0
        self.current_workers = {}
        # start date for workinstrunction and routing will be delayed based on the MONTHS_GAP_AFTER_MBOM
        self.start_date_for_production_phases = self.get_max_mbom_deadline() + timedelta(days=GAP_AFTER_MBOM_IN_DAYS)
        self.schedule_log = []  # list of dicts for CSV/Gantt

    def log(self, message):
        if global_logger is not None:
            global_logger.info(f"{self.current_time.strftime('%Y-%m-%d %H:%M')} - {message}")
        else:
            print(message)

    def logdebug(self, message):
        if global_logger is not None:
            global_logger.debug(f"{self.current_time.strftime('%Y-%m-%d %H:%M')} - {message}")
        else:
            print(message)


    def run(self):
        end_time = START_DATE + timedelta(days=ELAPSED_DAYS)
        self.log(f"\n\n🕒 Simulation starts: {format_time(self.current_time)}")
        self.log(f"🕒   expected end at: {format_time(end_time)}\n")

        is_working_time = False
        current_shift_num = -1
        current_shift_idx = -1
        simulation_failed = False

        # =======================================
        # =====          main loop          =====
        # =======================================
        while self.current_time <= end_time and not simulation_failed:
            self.logdebug(f"\n=== ⏱️ Time Tick: {format_time(self.current_time)} ===")
            htick = TICK.total_seconds() / 3600  # Convert TICK to hours

            is_shift_starting, shift_num, shift_idx = self.is_shift_start(self.current_time)
            if is_shift_starting:
                self.logdebug("--------------------------------")
                self.logdebug(f"🕒 {format_date(self.current_time)} - Shift {shift_num} start at {format_time_only(self.current_time)}")
                self.current_workers = self.reset_workers()
                is_working_time = True
                current_shift_num = shift_num
                current_shift_idx = shift_idx

            if is_working_time:
                self.logdebug("    available   " + str([f"{ebomid}.{task['name']}" for ebomid, task in self.get_available_tasks()]))
                for ebomid, task in self.get_available_tasks():
                    worker_id_on_closed_task = None
                    #if task['active_worker'] is not None:
                    #    self.log(f"    🐞 task: {ebomid}.{task['name']}, active_worker:{task['active_worker']}, remaining_cost:{task['remaining_cost']:.1f}")

                    # check if this task is currently in progress
                    if task['active_worker'] is not None and task['remaining_cost'] > 0:
                        # decrease remaining cost for this task
                        task['remaining_cost'] -= htick
                        # increase working time for the worker
                        self.current_workers[task['active_worker']]['working_hours'] += htick
                    
                    # check if we can close this task
                    if task['active_worker'] is not None and task['remaining_cost'] <= 0:
                        self.log(f"    🛬 task: {ebomid}.{task['name']} completed by {task['active_worker']} at {format_time(self.current_time + TICK)}")
                        # finalize this task
                        self.schedule_log_append(ebomid, task, current_shift_num)
                        worker_id_on_closed_task = task['active_worker']
                        self.current_workers[task['active_worker']]['current_task'] = None
                        task['active_worker'] = None

                        # todo: check if this token is closed before the deadline

                        # get next task in this ebom
                        ebom = next(e for e in self.eboms if e["id"] == ebomid)
                        if len(ebom['phases']) > (task['id'] + 1):
                            task = ebom['phases'][task['id'] + 1]
                        else:
                            task = None

                    # check if we can assign the task to a worker
                    this_task_can_be_assigned = self.task_can_be_assigned(task)
                    if this_task_can_be_assigned == 'ok':
                        worker_id = self.get_first_available_worker_with_max_capacity(not_the_worker = worker_id_on_closed_task, current_shift_num=current_shift_num)  
                        if worker_id is not None:
                            # assign this task to a worker
                            task['remaining_cost'] -= htick
                            task['active_worker'] = worker_id
                            self.current_workers[worker_id]['current_task'] = f"{ebomid}.{task['name']}"
                            self.current_workers[worker_id]['current_task_start'] = self.current_time
                            self.current_workers[worker_id]['working_hours'] += htick
                            self.add_worker_to_shift_workers_list(worker_id, shift_num, shift_idx)    
                            self.log(f"    👷 task: {ebomid}.{task['name']} assigned to {task['active_worker']} at {format_time(self.current_time)}")
                    else:
                        if ebomid is not None  and task is not None:
                                self.logdebug(f"    🐞 task: {ebomid}.{task['name']} cannot be assigned, reason: {this_task_can_be_assigned}")

            is_shift_ending, shift_num = self.is_shift_end(self.current_time)
            if is_shift_ending:
                self.logdebug(f"🕒 {format_date(self.current_time)} - Shift {shift_num} end at  {format_time_only(self.current_time)}")
                # todo: check worker saturation
                # close shift, reset assignments
                # log all workers, they will be reassigned in the next shift
                for ebomid, task in self.get_available_tasks():
                    self.schedule_log_append(ebomid, task, current_shift_num)
                self.reset_eboms_assignement_to_workers()
                is_working_time = False
                current_shift_num = -1
                current_shift_idx = -1
                # # log current status of all eboms,  only for debug
                # self.log(f"    🐞 Current EBOMs status at end of shift {shift_num}:")
                # for ebom in self.eboms:
                #     self.log(f"      🐞 {ebom['id']}:")
                #     for phase in ebom["phases"]:
                #         self.log(f"      🐞    {phase['name']}: {phase['remaining_cost']:.1f}h remaining, deadline: {format_date(phase['deadline'])}")

            if not is_working_time:
                if self.current_time.date() < self.start_date_for_production_phases.date():
                    # we can check if all mboms are completed
                    if len(self.get_uncompleted_mboms()) == 0:
                        self.log(f"✅ {format_time(self.current_time)} - All MBOMs completed , skip next tick till the starting on production phases")
                        self.current_time = self.start_date_for_production_phases
                if self.current_time.date() > self.start_date_for_production_phases.date(): # todo this should be > of mbom deadline
                    if len(self.get_uncompleted_mboms()) > 0:
                        self.log(f"⚠️ {format_time(self.current_time)} - Simulation failed: NOT all MBOMs were completed before production start date {format_time(self.start_date_for_production_phases)}")
                        simulation_failed = True
                if self.current_time.date() > self.start_date_for_production_phases.date():
                    # we can check if all eboms are completed
                    if len(self.get_uncompleted_eboms()) == 0:
                        self.log(f"✅ {format_time(self.current_time)} - All EBOMs completed , simulation can end")
                        self.current_time = end_time

            # _mme  da rivedere / scommentare
            #if not is_working_time and len(self.get_uncompleted_mboms_with_past_deadline()) > 0 and self.current_time > self.start_date_for_production_phases:  
            #    # if not all mbom are finished before the production start date 
            #    log(f"⚠️ {format_time(self.current_time)} - Simulation failed: NOT All MBOMs were completed before production start date {format_time(self.start_date_for_production_phases)}")
            #    simulation_failed = True
                
            self.current_time += TICK

        self.log(f"✅ Simulation ended at {format_time(self.current_time)}\n")

        self.log("=========================")
        # Check if all mboms are completed before the production start date
        uncompleted_eboms = self.get_uncompleted_eboms()
        if uncompleted_eboms:
            self.log(f"⚠️ Uncompleted EBOMs: {len(uncompleted_eboms)}")
            self.print_remaining_tasks()
        else:
            self.log("📦 All EBOMs completed!")
        self.log(f"👷 Workers Used: {self.monthly_workers}")
        self.log("=========================\n")


    def task_can_be_assigned(self, task):
        if task is None:
            return "task_none"

        # check if this task is already assigned to a worker
        if task['active_worker'] is not None:
            return "task_assigned"

        # check if this task is already completed
        if task['remaining_cost'] <= 0:
            return "task_completed"

        # check if this task is not mbom and it is in the future
        if task['name'] != "mbom" and self.current_time < self.start_date_for_production_phases:
            return "task_not_mbom"

        if self.current_time.date() > task["deadline"].date():
            return "task_overdue"

        return "ok"

    def get_max_mbom_deadline(self):
        max_deadline = datetime(1971, 1, 1)
        for ebom in self.eboms:
            if ebom["phases"][0]["deadline"] > max_deadline:
                max_deadline = ebom["phases"][0]["deadline"]
        return max_deadline

    def schedule_log_append(self, ebomid, task, shift_num):
        # log for csv * gantt
        if task['active_worker'] != None:
            self.schedule_log.append({
                "worker": task['active_worker'],
                "task": f"{ebomid}.{task['name']}",
                "shift": shift_num,
                "start": self.current_workers[task['active_worker']]['current_task_start'],
                "end": self.current_time
            })

    def reset_workers(self):
        self.logdebug(f"    🐞 _mme reset_workers")
        workers = {}
        # get the number of workers for the current month
        shift_month = (self.current_time.year, self.current_time.month)
        num_workers = self.monthly_workers.get(shift_month, 1)
        shift_nums = list({shift["shift_num"] for shift in self.shifts})
        shifti = 0
        shiftlen = len(shift_nums)
        for i in range(num_workers):
            workers[f"W{i+1}"] = {
                "id": f"W{i+1}",
                "current_task": None,
                "current_task_start": None,
                "working_hours": 0,
                "shift_num_assigned": shift_nums[shifti % shiftlen]
            }
            shifti = shifti + 1
        return workers

    def reset_eboms_assignement_to_workers(self):
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                phase["active_worker"] = None
        self.available_tasks = [(ebom["id"], 0) for ebom in self.eboms]
            
    def get_available_tasks(self):
        available_tasks = []
        for ebom in self.eboms:
            phase_added = False
            for phase_idx, phase in enumerate(ebom["phases"]):
                if not phase_added and phase["remaining_cost"] > 0 and self.current_time >= ebom["eng_release_date"]:
                    available_tasks.append((ebom["id"], phase))
                    phase_added = True
        return available_tasks

    def get_first_available_worker_with_max_capacity(self, not_the_worker=None, current_shift_num=-1):
        # Only consider workers assigned to the current shift
        workers = [
            worker_id
            for worker_id, worker_info in self.current_workers.items()
            if worker_info['shift_num_assigned'] == current_shift_num
        ]
        # remove workers that are already engaged
        for ebom in self.eboms:
            for phase_idx, phase in enumerate(ebom["phases"]):
                if phase['active_worker'] is not None:
                    workers.remove(phase['active_worker'])
        # remove specific worker if provided
        if not_the_worker in workers:
            workers.remove(not_the_worker)
        # check workers that was not already engaged on a different shift today
        today = self.current_time.date()
        workers = [
            w for w in workers
            if all(
                w not in shift["shift_workers"]
                for shift in self.shifts
                if shift["start"].date() == today and shift["shift_num"] != current_shift_num
            )
        ]
        if len(workers) > 0:
            # return worker that has the least working hours
            return min(workers, key=lambda w: self.current_workers[w]['working_hours'])
        return None

    def get_first_available_worker(self, not_the_worker=None):
        workers = [f"W{i+1}" for i in range(len(self.current_workers))]
        for ebom in self.eboms:
            for phase_idx, phase in enumerate(ebom["phases"]):
                if phase['active_worker'] is not None:
                    workers.remove(phase['active_worker'])
        if not_the_worker in workers:
            workers.remove(not_the_worker)
        if len(workers) > 0:
            return workers[0]
        return None
    
    def add_worker_to_shift_workers_list(self, worker_id, shift_num, shift_idx):
        if worker_id not in self.shifts[shift_idx]["shift_workers"]:
            self.shifts[shift_idx]["shift_workers"].append(worker_id)

    def get_uncompleted_eboms(self):
        unceboms = set()
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                if phase["remaining_cost"] > 0:
                    unceboms.add(ebom["id"])
                    break
        return [ebom for ebom in self.eboms if ebom["id"] in unceboms]

    def get_uncompleted_mboms(self):
        uncmboms = set()
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                if phase["name"] == "mbom" and phase["remaining_cost"] > 0:
                    uncmboms.add(ebom["id"])
                    break
        return [ebom for ebom in self.eboms if ebom["id"] in uncmboms]
    
    def get_uncompleted_wi_routing(self):
        uncompleted_wi_r = set()
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                if (phase["name"] == "workinstruction" or phase["name"] == "routing") and phase["remaining_cost"] > 0:
                    uncompleted_wi_r.add(ebom["id"])
                    break
        return [ebom for ebom in self.eboms if ebom["id"] in uncompleted_wi_r]

    def get_uncompleted_mboms_with_past_deadline(self):
        uncmboms = set()
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                if phase["name"] == "mbom" and phase["remaining_cost"] > 0 and self.current_time > phase["deadline"]:
                    uncmboms.add(ebom["id"])
                    break
        return [ebom for ebom in self.eboms if ebom["id"] in uncmboms]


    def is_shift_start(self, curtime):
        for idx, shift in enumerate(self.shifts):
            if shift["start"] == curtime:
                # shift cannot start if all mbom are completed and we are behind the production date start
                if len(self.get_uncompleted_mboms()) == 0 and self.current_time < self.start_date_for_production_phases:
                    return False, -1, -1
                return True, shift["shift_num"], idx
        return False, -1, -1

    def is_shift_end(self, curtime):
        for shift in self.shifts:
            if shift["end"] == curtime:
                return True, shift["shift_num"]
        return False, -1

    def print_remaining_tasks(self):
        self.log(f"    🐞 Remaining tasks:")
        for ebom in eboms:
            for phase in ebom["phases"]:
                if phase["name"] == "mbom" and phase["remaining_cost"] > 0:
                    self.log(f"    🐞    {ebom['id']}.{phase['name']} : remaining cost: {phase['remaining_cost']:.1f}")
        for ebom in eboms:
            for phase in ebom["phases"]:
                if phase["name"] == "workinstruction" and phase["remaining_cost"] > 0:
                    self.log(f"    🐞    {ebom['id']}.{phase['name']} : remaining cost: {phase['remaining_cost']:.1f}")
        for ebom in eboms:
            for phase in ebom["phases"]:
                if phase["name"] == "routing" and phase["remaining_cost"] > 0:
                    self.log(f"    🐞    {ebom['id']}.{phase['name']} : remaining cost: {phase['remaining_cost']:.1f}")




# _mme review def optimize_monthly_workers(base_config, iterations=10):
# _mme review     """
# _mme review     Function to test different monthly worker configurations and find optimal allocation
# _mme review     """
# _mme review     log_ext(f"\n🔄 Starting optimization with {iterations} iterations...")
# _mme review     
# _mme review     best_config = None
# _mme review     best_score = float('inf')
# _mme review     results = []
# _mme review     
# _mme review     for iteration in range(iterations):
# _mme review         # Generate a variation of the base configuration
# _mme review         test_config = base_config.copy()
# _mme review         
# _mme review         # Apply random variations (±1 or ±2 workers per month)
# _mme review         for i in range(len(test_config)):
# _mme review             if random.random() < 0.3:  # 30% chance to modify each month
# _mme review                 variation = random.choice([-2, -1, 1, 2])
# _mme review                 test_config[i] = max(1, test_config[i] + variation)  # Ensure at least 1 worker
# _mme review         
# _mme review         # Test this configuration
# _mme review         global MONTHLY_MAX_WORKERS
# _mme review         original_config = MONTHLY_MAX_WORKERS.copy()
# _mme review         MONTHLY_MAX_WORKERS = test_config
# _mme review         
# _mme review         try:
# _mme review             # Generate new test data for this iteration
# _mme review             eboms = generate_eboms(NUM_EBOMS)
# _mme review             shifts = generate_shifts(START_DATE, ELAPSED_DAYS)
# _mme review             
# _mme review             # Run simulation
# _mme review             sim = PetriNetSimulator(eboms, shifts)
# _mme review             sim.run()
# _mme review             
# _mme review             # Calculate score (lower is better)
# _mme review             total_workers = sum(test_config)
# _mme review             uncompleted_count = len(sim.get_uncompleted_eboms())
# _mme review             
# _mme review             # Score formula: prioritize completion, then minimize workers
# _mme review             score = uncompleted_count * 1000 + total_workers
# _mme review             
# _mme review             results.append({
# _mme review                 'iteration': iteration + 1,
# _mme review                 'config': test_config.copy(),
# _mme review                 'total_workers': total_workers,
# _mme review                 'uncompleted_eboms': uncompleted_count,
# _mme review                 'score': score,
# _mme review                 'monthly_stats': sim.monthly_usage_stats.copy()
# _mme review             })
# _mme review             
# _mme review             if score < best_score:
# _mme review                 best_score = score
# _mme review                 best_config = test_config.copy()
# _mme review                 log_ext(f"  ✅ New best config found (iteration {iteration + 1}): Score={score}, Workers={total_workers}, Uncompleted={uncompleted_count}")
# _mme review             else:
# _mme review                 log_ext(f"  📊 Iteration {iteration + 1}: Score={score}, Workers={total_workers}, Uncompleted={uncompleted_count}")
# _mme review                 
# _mme review         except Exception as e:
# _mme review             log_ext(f"  ❌ Iteration {iteration + 1} failed: {str(e)}")
# _mme review             
# _mme review         finally:
# _mme review             # Restore original configuration
# _mme review             MONTHLY_MAX_WORKERS = original_config
# _mme review     
# _mme review     # Set the best configuration
# _mme review     if best_config:
# _mme review         MONTHLY_MAX_WORKERS = best_config
# _mme review         log_ext(f"\n🏆 Best configuration found:")
# _mme review         log_ext(f"  Total workers across all months: {sum(best_config)}")
# _mme review         log_ext(f"  Monthly allocation: {best_config}")
# _mme review         log_ext(f"  Final score: {best_score}")
# _mme review     
# _mme review     return results, best_config




# ---------------- MAIN ENTRY ---------------- #
if __name__ == "__main__":
    log_file = 'logs\massive_planning.log'
    if os.path.exists(log_file):
        os.remove(log_file)
    logger = setup_logger(log_file)
    
    goon = True
    # Generate EBOMs
    eboms = generate_eboms(NUM_EBOMS)
    log_ext("\n📋 EBOMs Generated:")
    for ebom in eboms:
        log_ext(f"  🏷️ {ebom['id']}  -  eng. release: {format_date(ebom['eng_release_date'])}")
        for phase in ebom["phases"]:
            log_ext(f"    - {phase['name']} (Deadline: {format_date(phase['deadline'])}), Cost: {phase['cost']}h")

    START_DATE = get_min_eng_release_date(eboms)
    END_DATE = get_min_cassa_production_date(casse_production_dates)
    ELAPSED_DAYS = (END_DATE - START_DATE).days
    months = get_month_list(START_DATE, ELAPSED_DAYS)

    shifts = generate_shifts(START_DATE, ELAPSED_DAYS, months)
    log_ext("\n🛠️ Shifts Generated:")
    for i, shift in enumerate(shifts):
        msg = f"  📆 {format_time(shift['start'])} - Shift {shift['shift_num']} (Duration: {shift['duration']}h)"
        if i < 3: log_ext(msg)
        elif i == 3: 
            log_ext("  📆  ...")
            log_ext_debug(msg)
        elif i >= len(shifts) - 3: log_ext(msg)
        else: log_ext_debug(msg)
    if not goon: exit()

    
    log_ext("⚙️  Configuration:")
    log_ext(f"⚙️    NUM_EBOMS = {NUM_EBOMS}")
    log_ext(f"⚙️    SHIFT_CONFIG = {SHIFT_CONFIG}")
    log_ext(f"⚙️    TICK = {TICK}")
    log_ext(f"⚙️    START_DATE = {START_DATE}")
    log_ext(f"⚙️    END_DATE = {END_DATE}")
    log_ext(f"⚙️    ELAPSED_DAYS = {ELAPSED_DAYS}")
    log_ext(f"⚙️    GAP_AFTER_MBOM_IN_DAYS = {GAP_AFTER_MBOM_IN_DAYS}")
    log_ext(f"⚙️    MONTHS = {months}")
    if not goon: exit()


    # log total costs
    log_ext("\n---------------------")
    log_ext("💰 Total Costs:")
    log_ext(f"  start date: {format_date(START_DATE)}")
    log_ext(f"  end date: {format_date(START_DATE + timedelta(days=ELAPSED_DAYS))}")
    total_engineering_cost = sum(phase["cost"] for ebom in eboms for phase in ebom["phases"] if phase["name"] == "mbom")
    total_production_cost = sum(phase["cost"] for ebom in eboms for phase in ebom["phases"] if phase["name"] != "mbom")
    log_ext(f"  {total_engineering_cost:.2f}h    :  Total Engineering (mbom) Cost")
    log_ext(f"  {total_production_cost:.2f}h    :  Total Production (not mbom) Cost")
    max_mbom_deadline = max(ebom["phases"][0]["deadline"] for ebom in eboms)
    mbom_elapsed_days = (max_mbom_deadline - START_DATE).days
    log_ext(f"  {format_date(max_mbom_deadline)} : Max MBOM Deadline (Elapsed Days: {mbom_elapsed_days})")
    daily_hours_per_worker = sum(shift["duration"] for shift in SHIFT_CONFIG.values()) / len(SHIFT_CONFIG)
    min_num_workers_needed_for_mbom = math.floor(total_engineering_cost / daily_hours_per_worker / mbom_elapsed_days)
    log_ext(f"  {daily_hours_per_worker:.2f}    :  daily_workers_hours")
    log_ext(f"  {min_num_workers_needed_for_mbom}    :  Theorical number of workers needed for mbom phases (round down)")
    log_ext(f"      = {total_engineering_cost:.2f}h total engineering cost  / {daily_hours_per_worker}h/day / {mbom_elapsed_days} mbom_elapsed_days")
    if not goon: exit()
    log_ext("---------------------\n")
    #sys.exit(2)

    # rivedi _mme  # Option 1: Run with predefined monthly configuration
    # rivedi _mme  run_optimization = True
    # rivedi _mme  
    # rivedi _mme  if run_optimization:
    # rivedi _mme      # Option 2: Optimize the monthly worker allocation
    # rivedi _mme      initial_config = MONTHLY_MAX_WORKERS.copy()
    # rivedi _mme      optimization_results, best_config = optimize_monthly_workers(initial_config, iterations=5)
    # rivedi _mme      
    # rivedi _mme      # Export optimization results
    # rivedi _mme      opt_export_file = "logs/optimization_results.csv"
    # rivedi _mme      with open(opt_export_file, "w", newline="") as f:
    # rivedi _mme          writer = csv.DictWriter(f, fieldnames=["iteration", "total_workers", "uncompleted_eboms", "score"], delimiter=';')
    # rivedi _mme          writer.writeheader()
    # rivedi _mme          for result in optimization_results:
    # rivedi _mme              writer.writerow({
    # rivedi _mme                  "iteration": result["iteration"],
    # rivedi _mme                  "total_workers": result["total_workers"],
    # rivedi _mme                  "uncompleted_eboms": result["uncompleted_eboms"],
    # rivedi _mme                  "score": result["score"]
    # rivedi _mme              })
    # rivedi _mme      log_ext(f"✅ Optimization results exported: {opt_export_file}")
    # rivedi _mme  
    # rivedi _mme  # Run final simulation with best configuration
    # rivedi _mme  log_ext(f"\n{'='*60}")
    # rivedi _mme  log_ext("🏃 Running final simulation with optimized configuration...")



    ##################  simulation start
    # Create a dictionary mapping (year, month) → num_of_worker,  initialized with fixed num of workers
    num_of_workers_per_month = min_num_workers_needed_for_mbom 
    monthly_workers = {(year, month): int(math.ceil(num_of_workers_per_month)) for (year, month) in months}
    
    sim = PetriNetSimulator(eboms, shifts, monthly_workers)
    sim.run()



    export_file = "logs\massive_planning_schedule_export.csv"
    with open(export_file, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["worker", "task", "start", "end", "shift"], delimiter=';')
        writer.writeheader()
        for row in sim.schedule_log:
            writer.writerow({**row, "start": format_time(row["start"]), "end": format_time(row["end"])})
    log_ext(f"✅ CSV exported: {export_file}")

    export_file = "logs\massive_planning_status.txt"
    with open(export_file, "w") as f:
        f.write(f"\nSTART_DATE: {START_DATE}\n")
        f.write(f"ELAPSED_DAYS: {ELAPSED_DAYS} days\n")
        f.write(f"start_date_for_production_phases: {sim.start_date_for_production_phases}\n")
        f.write("\n")
        for ebom in sim.eboms:
            f.write(f"{ebom['id']}\n")
            f.write(f"eng_release_date: {format_date(ebom['eng_release_date'])}\n")
            for phase in ebom["phases"]:
                remaining_cost = round(phase["remaining_cost"], 2) if phase["remaining_cost"] > 0 else 0
                f.write(f"  - { phase['name']}: {remaining_cost}h remaining, deadline: {format_date(phase['deadline'])}, worker: {phase['active_worker']}\n")
            f.write("\n")
    log_ext(f"✅ Status exported: {export_file}")
    
    log_ext(f"log in: {log_file}")

