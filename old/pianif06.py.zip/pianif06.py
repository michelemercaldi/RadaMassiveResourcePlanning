import os
import random
from datetime import datetime, timedelta
from collections import defaultdict
import csv
import logging


# --- CONFIGURATION ---
NUM_EBOMS = 15
SHIFT_CONFIG = {
    1: {"start": "06:00", "duration": 7.5, "saturation": 0.9},
    2: {"start": "14:00", "duration": 7.5, "saturation": 0.9},
    #3: {"start": "22:00", "duration": 7.0, "saturation": 0.9},
}
START_DATE = datetime(2024, 5, 1)
TICK = timedelta(minutes=30)
PLANNING_DAYS = 25 * 30   #elapsed
MAX_WORKERS = 7

MONTHS_GAP_AFTER_MBOM = 5  # Enforce gap after mbom


# ---------------- HELPERS ---------------- #
global_logger = None
def format_time(dt): return dt.strftime("%Y-%m-%d %H:%M")
def format_date(dt): return dt.strftime("%Y-%m-%d")
def format_time_only(dt): return dt.strftime("%H:%M")

def setup_logger(log_file):
    global global_logger
    # Create a logger
    logger = logging.getLogger('pianif_logger')
    logger.setLevel(logging.INFO)  # Set the logging level

    # Create a file handler with utf-8 encoding
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.INFO)

    # Create a console handler with utf-8 encoding
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    # Create a formatter and set it for the handlers
    #formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    #formatter = logging.Formatter('%(asctime)s - %(message)s')
    formatter = logging.Formatter('%(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # Add the handlers to the logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    global_logger = logger
    return logger

def log_ext(message):
    if global_logger is not None:
        global_logger.info(message)
    else:
        print(message)


# --- TEAR UP FUNCTIONS ---
def generate_shifts(start_date, days):
    shifts = []
    for day in range(days):
        day_base = start_date + timedelta(days=day)
        for shift_num, conf in SHIFT_CONFIG.items():
            t = datetime.strptime(conf["start"], "%H:%M")
            shift_start = day_base.replace(hour=t.hour, minute=t.minute)
            shift_end = shift_start + timedelta(hours=conf["duration"])
            shifts.append({
                "shift_num": shift_num,
                "start": shift_start,
                "end": shift_end,
                "duration": conf["duration"],
                "saturation": conf["saturation"],
                "min_required": conf["duration"] * conf["saturation"],
                "workers": defaultdict(list)  # worker_id → list of (start, end, task)
            })
    return shifts


def generate_eboms(n):
    eboms = []
    daily_working_hours = sum(shift["duration"] for shift in SHIFT_CONFIG.values())  # total working hours in a day
    for i in range(n):
        base_start = START_DATE + timedelta(days=random.randint(0, 3))

        mbom_cost = round(random.uniform(30.0, 75), 1)
        wi_cost = round(random.uniform(30, 70), 1)
        routing_cost = round(random.uniform(30, 90), 1)

        # we add 1 to to cover the partial day of work, +2 to be more on the safe side 
        mbom_deadline = base_start + timedelta(days=(int(mbom_cost // daily_working_hours + 2)))
        wi_deadline = base_start + timedelta(PLANNING_DAYS) - timedelta(days=(int(wi_cost // daily_working_hours + 2)))
        routing_deadline = wi_deadline + timedelta(PLANNING_DAYS) - timedelta(days=(int(routing_cost // daily_working_hours + 2)))
        
        eboms.append({
            "id": f"EBOM{i+1}",
            "eng_release_date": base_start,
            "phases": [
                {
                    "id": 0,
                    "name": "mbom",
                    "deadline": mbom_deadline,
                    "cost": mbom_cost,
                    "remaining_cost": mbom_cost,
                    "active_worker": None
                },
                {
                    "id": 1,
                    "name": "workinstruction",
                    "deadline": wi_deadline,
                    "cost": wi_cost,
                    "remaining_cost": wi_cost,
                    "active_worker": None
                },
                {
                    "id": 2,
                    "name": "routing",
                    "deadline": routing_deadline,
                    "cost": routing_cost,
                    "remaining_cost": routing_cost,
                    "active_worker": None
                }
            ]
        })
    return eboms




# ---------------- PETRI NET SIMULATOR ---------------- #
class PetriNetSimulator:
    def __init__(self, eboms, shifts):
        self.eboms = eboms
        self.shifts = shifts
        self.current_time = START_DATE
        self.available_workers = [f"W{i+1}" for i in range(MAX_WORKERS)]
        self.in_progress = {}  # worker_id → {end, task}
        #self.tokens = [(ebom["id"], 0) for ebom in eboms]
        self.available_tasks = [(ebom["id"], 0) for ebom in eboms] # we start from phase 0
        self.workers = {}
        # start date for workinstrunction and routing will be delayed based on the MONTHS_GAP_AFTER_MBOM
        self.start_date_for_production_phases = self.get_max_mbom_deadline() + timedelta(days=MONTHS_GAP_AFTER_MBOM)
        self.schedule_log = []  # list of dicts for CSV/Gantt

    def log(self, message):
        if global_logger is not None:
            global_logger.info(f"{self.current_time.strftime('%Y-%m-%d %H:%M')} - {message}")
        else:
            print(message)

    def run(self):
        end_time = START_DATE + timedelta(days=PLANNING_DAYS)
        self.log(f"\n\n🕒 Simulation starts: {format_time(self.current_time)}")
        self.log(f"🕒   expected end at: {format_time(end_time)}\n")

        is_working_time = False
        current_shift_num = -1
        simulation_failed = False

        while self.current_time <= end_time and not simulation_failed:
            #log(f"\n=== ⏱️ Time Tick: {format_time(self.current_time)} ===")
            htick = TICK.total_seconds() / 3600  # Convert TICK to hours

            is_starting, shift_num = self.is_shift_start(self.current_time)
            if is_starting:
                self.log("--------------------------------")   # _mme shiftlog
                self.log(f"🕒 {format_date(self.current_time)} - Shift {shift_num} start at {format_time_only(self.current_time)}")   # _mme shiftlog
                self.workers = self.reset_workers()
                is_working_time = True
                current_shift_num = shift_num

            if is_working_time:
                #log(" _mme available   ", [f"{ebomid}.{task['name']}" for ebomid, task in self.get_available_tasks()])
                for ebomid, task in self.get_available_tasks():
                    worker_id_on_closed_task = None
                    #if task['active_worker'] is not None:
                    #    self.log(f"    🐞 task: {ebomid}.{task['name']}, active_worker:{task['active_worker']}, remaining_cost:{task['remaining_cost']:.1f}")

                    # check if this task is currently in progress
                    if task['active_worker'] is not None and task['remaining_cost'] > 0:
                        # decrease remaining cost for this task
                        task['remaining_cost'] -= htick
                        # increase working time for the worker
                        self.workers[task['active_worker']]['working_hours'] += htick
                    
                    # check if we can close this task
                    if task['active_worker'] is not None and task['remaining_cost'] <= 0:
                        self.log(f"    🛬 task: {ebomid}.{task['name']} completed by {task['active_worker']} at {format_time(self.current_time + TICK)}")
                        # finalize this task
                        self.schedule_log_append(ebomid, task, current_shift_num)
                        worker_id_on_closed_task = task['active_worker']
                        self.workers[task['active_worker']]['current_task'] = None
                        task['active_worker'] = None

                        # todo: check if this token is closed before the deadline

                        # get next task in this ebom
                        ebom = next(e for e in self.eboms if e["id"] == ebomid)
                        if len(ebom['phases']) > (task['id'] + 1):
                            task = ebom['phases'][task['id'] + 1]
                        else:
                            task = None

                    # check if we can assign the task to a worker
                    # if self.current_time > self.start_date_for_production_phases: log(f" _mme canbe ass: {self.task_can_be_assigned(task)}")
                    this_task_can_be_asssigned = self.task_can_be_assigned(task)
                    if this_task_can_be_asssigned == 'ok':
                        worker_id = self.get_first_available_worker_with_max_capacity(not_the_worker = worker_id_on_closed_task)
                        if worker_id is not None:
                            # assign this task to a worker
                            task['remaining_cost'] -= htick
                            task['active_worker'] = worker_id
                            self.workers[worker_id]['current_task'] = f"{ebomid}.{task['name']}"
                            self.workers[worker_id]['current_task_start'] = self.current_time
                            self.workers[worker_id]['working_hours'] += htick
                            self.log(f"    👷 task: {ebomid}.{task['name']} assigned to {task['active_worker']} at {format_time(self.current_time)}")
                    else:
                        if ebomid is not None  and task is not None:
                                self.log(f"    🐞 task: {ebomid}.{task['name']} cannot be assigned, reason: {this_task_can_be_asssigned}")

            is_ending, shift_num = self.is_shift_end(self.current_time)
            if is_ending:
                self.log(f"🕒 {format_date(self.current_time)} - Shift {shift_num} end at  {format_time_only(self.current_time)}")   # _mme shiftlog
                # todo: check worker saturation
                # close shift, reset assignments
                self.reset_eboms_assignement_to_workers()
                # log all workers, they will be reassigned in the next shift
                for ebomid, task in self.get_available_tasks():
                    self.schedule_log_append(ebomid, task, current_shift_num)
                is_working_time = False
                current_shift_num = -1
                # log current status of all eboms
                self.log(f"    🐞 Current EBOMs status at end of shift {shift_num}:")
                for ebom in self.eboms:
                    self.log(f"      🐞 {ebom['id']}:")
                    for phase in ebom["phases"]:
                        self.log(f"      🐞    {phase['name']}: {phase['remaining_cost']:.1f}h remaining, deadline: {format_date(phase['deadline'])}")

            # _mme  da rivedere / scommentare
            #if not is_working_time and len(self.get_uncompleted_mboms_with_past_deadline()) > 0 and self.current_time > self.start_date_for_production_phases:  
            #    # if not all mbom are finished before the production start date 
            #    log(f"⚠️ {format_time(self.current_time)} - Simulation failed: NOT All MBOMs were completed before production start date {format_time(self.start_date_for_production_phases)}")
            #    simulation_failed = True
                
            self.current_time += TICK

        self.log(f"\n✅ Simulation ended at {format_time(self.current_time)}")
        self.log(f"👷 Workers Used: {MAX_WORKERS}")

        uncompleted_eboms = self.get_uncompleted_eboms()
        if uncompleted_eboms:
            self.log(f"⚠️ Uncompleted EBOMs: {len(uncompleted_eboms)}")
            self.print_remaining_tasks()
        else:
            self.log("📦 All EBOMs completed!")


    def task_can_be_assigned(self, task):
        if task is None:
            return "task_none"

        # check if this task is already assigned to a worker
        if task['active_worker'] is not None:
            return "task_assigned"

        # check if this task is already completed
        if task['remaining_cost'] <= 0:
            return "task_completed"

        # check if this task is not mbom and it is in the future
        if task['name'] != "mbom" and self.current_time < self.start_date_for_production_phases:
            return "task_not_mbom"

        if self.current_time.date() > task["deadline"].date():
            return "task_overdue"

        return "ok"

    def get_max_mbom_deadline(self):
        max_deadline = datetime(1971, 1, 1)
        for ebom in self.eboms:
            if ebom["phases"][0]["deadline"] > max_deadline:
                max_deadline = ebom["phases"][0]["deadline"]
        return max_deadline

    def schedule_log_append(self, ebomid, task, shift_num):
        # log for csv * gantt
        if task['active_worker'] != None:
            self.schedule_log.append({
                "worker": task['active_worker'],
                "task": f"{ebomid}.{task['name']}",
                "shift": shift_num,
                "start": self.workers[task['active_worker']]['current_task_start'],
                "end": self.current_time
            })

    def reset_workers(self):
        workers = {}
        for i in range(MAX_WORKERS):
            workers[f"W{i+1}"] = {
                "id": f"W{i+1}",
                "current_task": None,
                "current_task_start": None,
                "working_hours": 0
            }
        return workers

    def reset_eboms_assignement_to_workers(self):
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                phase["active_worker"] = None
        self.available_tasks = [(ebom["id"], 0) for ebom in self.eboms]
            
    def get_available_tasks(self):
        available_tasks = []
        for ebom in self.eboms:
            phase_added = False
            for phase_idx, phase in enumerate(ebom["phases"]):
                if not phase_added and phase["remaining_cost"] > 0 and self.current_time >= ebom["eng_release_date"]:
                    available_tasks.append((ebom["id"], phase))
                    phase_added = True
        return available_tasks

    def get_first_available_worker_with_max_capacity(self, not_the_worker=None):
        # todo : get worker with max available capacity
        workers = [f"W{i+1}" for i in range(MAX_WORKERS)]
        for ebom in self.eboms:
            for phase_idx, phase in enumerate(ebom["phases"]):
                if phase['active_worker'] is not None:
                    workers.remove(phase['active_worker'])
        if not_the_worker in workers:
            workers.remove(not_the_worker)
        if len(workers) > 0:
            # return worker that has the least working hours
            return min(workers, key=lambda w: self.workers[w]['working_hours'])
        return None

    def get_first_available_worker(self, not_the_worker=None):
        # todo : get worker with max available capacity
        workers = [f"W{i+1}" for i in range(MAX_WORKERS)]
        for ebom in self.eboms:
            for phase_idx, phase in enumerate(ebom["phases"]):
                if phase['active_worker'] is not None:
                    workers.remove(phase['active_worker'])
        if not_the_worker in workers:
            workers.remove(not_the_worker)
        if len(workers) > 0:
            return workers[0]
        return None

    def get_uncompleted_eboms(self):
        unceboms = set()
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                if phase["remaining_cost"] > 0:
                    unceboms.add(ebom["id"])
                    break
        return [ebom for ebom in self.eboms if ebom["id"] in unceboms]

    def get_uncompleted_mboms(self):
        uncmboms = set()
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                if phase["name"] == "mbom" and phase["remaining_cost"] > 0:
                    uncmboms.add(ebom["id"])
                    break
        return [ebom for ebom in self.eboms if ebom["id"] in uncmboms]
    
    def get_uncompleted_mboms_with_past_deadline(self):
        uncmboms = set()
        for ebom in self.eboms:
            for phase in ebom["phases"]:
                if phase["name"] == "mbom" and phase["remaining_cost"] > 0 and self.current_time > phase["deadline"]:
                    uncmboms.add(ebom["id"])
                    break
        return [ebom for ebom in self.eboms if ebom["id"] in uncmboms]

    def is_shift_start(self, curtime):
        for shift in self.shifts:
            if shift["start"] == curtime:
                # shift cannot start if all mbom are completed and we are behind the production date start
                if len(self.get_uncompleted_mboms()) == 0 and self.current_time < self.start_date_for_production_phases:
                    #log(f'_mme  {self.current_time} no for {self.start_date_for_production_phases}')
                    return False, -1
                return True, shift["shift_num"]
        return False, -1

    def is_shift_end(self, curtime):
        for shift in self.shifts:
            if shift["end"] == curtime:
                return True, shift["shift_num"]
        return False, -1

    def print_remaining_tasks(self):
        self.log(f"    🐞 Remaining tasks:")
        for ebom in eboms:
            for phase in ebom["phases"]:
                if phase["remaining_cost"] > 0:
                    self.log(f"    🐞    {ebom['id']}.{phase['name']} : remaining cost: {phase['remaining_cost']:.1f}")





# ---------------- MAIN ENTRY ---------------- #
if __name__ == "__main__":
    log_file = 'logs\massive_planning.log'
    if os.path.exists(log_file):
        os.remove(log_file)
    logger = setup_logger(log_file)
    
    goon = True
    shifts = generate_shifts(START_DATE, PLANNING_DAYS)
    log_ext("🛠️ Shifts Generated:")
    for shift in shifts:
        log_ext(f"  📆 {format_time(shift['start'])} - Shift {shift['shift_num']} (Duration: {shift['duration']}h, Min Required: {shift['min_required']}h)")
    if not goon: exit()

    # Generate EBOMs
    eboms = generate_eboms(NUM_EBOMS)
    log_ext("\n📋 EBOMs Generated:")
    for ebom in eboms:
        log_ext(f"  🏷️ {ebom['id']}  -  eng. release: {format_date(ebom['eng_release_date'])}")
        for phase in ebom["phases"]:
            log_ext(f"    - {phase['name']} (Deadline: {format_date(phase['deadline'])}), Cost: {phase['cost']}h")

    # log total costs
    total_engineering_cost = sum(phase["cost"] for ebom in eboms for phase in ebom["phases"] if phase["name"] == "mbom")
    total_production_cost = sum(phase["cost"] for ebom in eboms for phase in ebom["phases"] if phase["name"] != "mbom")
    log_ext(f"  {total_engineering_cost:.2f}h    :  Total Engineering (mbom) Cost")
    log_ext(f"  {total_production_cost:.2f}h    :  Total Production (not mbom) Cost")
    max_mbom_deadline = max(ebom["phases"][0]["deadline"] for ebom in eboms)
    mbom_elapsed_days = (max_mbom_deadline - START_DATE).days
    log_ext(f"  {format_date(max_mbom_deadline)} : Max MBOM Deadline (Elapsed Days: {mbom_elapsed_days})")
    daily_workers_hours = sum(shift["duration"] for shift in SHIFT_CONFIG.values())
    mbom_working_hours_that_can_be_used = mbom_elapsed_days * MAX_WORKERS * daily_workers_hours
    log_ext(f"  {mbom_working_hours_that_can_be_used:.2f}h    :  Working Hours that can be used for mbom")
    log_ext(f"      = {mbom_elapsed_days} days * {MAX_WORKERS} workers * {daily_workers_hours}h/day")
    teorical_num_workers_needed = total_engineering_cost / daily_workers_hours / mbom_elapsed_days
    log_ext(f"  {teorical_num_workers_needed:.2f}    :  Teorical number of workers needed for mbom phases")
    log_ext(f"      = {total_engineering_cost:.2f}h total cost  / {daily_workers_hours}h/day / {mbom_elapsed_days} mbom_elapsed_days")
    if not goon: exit()


    sim = PetriNetSimulator(eboms, shifts)
    sim.run()

    export_file = "logs\massive_planning_schedule_export.csv"
    with open(export_file, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["worker", "task", "start", "end", "shift"], delimiter=';')
        writer.writeheader()
        for row in sim.schedule_log:
            writer.writerow({**row, "start": format_time(row["start"]), "end": format_time(row["end"])})
    log_ext(f"✅ CSV exported: {export_file}")

    export_file = "logs\massive_planning_status.txt"
    with open(export_file, "w") as f:
        f.write(f"\nStart: {START_DATE}")
        f.write(f"total PLANNING_DAYS: {PLANNING_DAYS} days\n")
        f.write(f"start_date_for_production_phases: {sim.start_date_for_production_phases}\n")
        f.write("\n")
        for ebom in sim.eboms:
            f.write(f"{ebom['id']}\n")
            f.write(f"eng_release_date: {ebom['eng_release_date']}\n")
            for phase in ebom["phases"]:
                remaining_cost = round(phase["remaining_cost"], 2) if phase["remaining_cost"] > 0 else 0
                f.write(f"  - { phase['name']}: {remaining_cost}h remaining, deadline: {phase['deadline']}, worker: {phase['active_worker']}\n")
            f.write("\n")
    log_ext(f"✅ Status exported: {export_file}")
    log_ext(f"log in: {log_file}")

