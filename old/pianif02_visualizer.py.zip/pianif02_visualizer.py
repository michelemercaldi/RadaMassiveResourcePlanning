import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
from datetime import datetime

def plot_gantt_from_csv(csv_path):
    df = pd.read_csv(csv_path, delimiter=";")
    df["start"] = pd.to_datetime(df["start"])
    df["end"] = pd.to_datetime(df["end"])
    df.sort_values(by=["worker", "start"], inplace=True)

    fig, ax = plt.subplots(figsize=(15, 8))
    workers = df["worker"].unique()
    colors = plt.cm.get_cmap("tab20", len(workers))

    worker_indices = {worker: i for i, worker in enumerate(workers)}
    yticks = []
    ylabels = []

    for i, worker in enumerate(workers):
        worker_df = df[df["worker"] == worker]
        yticks.append(i)
        ylabels.append(worker)

        for j, row in worker_df.iterrows():
            ax.barh(
                y=i,
                left=row["start"],
                width=row["end"] - row["start"],
                height=0.4,
                color=colors(i),
                edgecolor="black"
            )
            label = f"{row['ebom']}.{row['phase']}"
            ax.text(
                row["start"] + (row["end"] - row["start"]) / 2,
                i,
                label,
                va="center",
                ha="center",
                color="white",
                fontsize=8,
                clip_on=True
            )

    ax.set_yticks(yticks)
    ax.set_yticklabels(ylabels)
    ax.set_xlabel("Time")
    ax.set_title("EBOM Phase Execution Timeline (Split-Aware Gantt Chart)")
    ax.grid(True, which="major", axis="x", linestyle="--", alpha=0.5)

    ax.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
