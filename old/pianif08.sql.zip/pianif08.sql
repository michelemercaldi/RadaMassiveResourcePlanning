
-----------------
-- INPUT UTENTE

----  id progetto  :  83

----  turni (1, 2, C)

----  data inizio produzione per ogni cassa
--       casse_production_dates = 
--       {'V1':'23/09/2025', 'V2':'23/10/2025', 'V3':'23/11/2025', 'V4':'23/12/2025'}

---- fattore conversione   ebom --> DRT ,  default = 3
 
---- costo orario per  MBOM, WORKINSTRUCTION, ROUTING 
--      da proporre quello nel DB , ma modificabile sul progetto scelto
select Descrizione, COSTOUNITARIOH, FLGEBOM, FLGPRODUZIONE,FLGMANUALI, OFFSETENG, OFFSETPROD 
from RST_ATTIVITAWL where Descrizione in ('M-BOM', 'WORK INSTRUCTION', 'ROUTING');
--                    COSTOUNITARIOH
-- M-BOM                  0
-- WORK INSTRUCTION      40
-- ROUTING                2
-- 
--  numero ore complessive non aggregato = 
--        Numero Eboms * Numero Dtr4 * (costo H Mbom) 
--      + Numero Eboms * Numero Dtr4 * (costo H WorkInstruction) 
--      + Numero Eboms * Numero Dtr4 * (costo H Routing)
--  es: 450 Ebom
--      3 DTR4 per Ebom
--    450 * 3 + 450 * 3 * 40 + 450 * 3 * 5 =  62100
 

 
-----------------
-- DA DATABASE

---- lista e numero di ebom, non considero gli ebom specifici per commessa
select distinct partnbr from rst_anagraficheebom where idcommessa = 71;

---- casse per ebom
--with ebom_casse as (
    select distinct an.partnbr, ap.veicolocassa
    from rst_anagraficheebom an join rst_applicazioniebom ap on ap.idanagrafica = an.id 
    where idcommessa = 71 and ap.quantita>0
    order by an.partnbr, veicolocassa
--) select distinct veicolocassa from ebom_casse
;

---- data rilascio per ogni ebom
--      minima data di rilascio per ogni applicabilita' dell'ebom
with md as (
    -- max data rilascio ingegneria, da usare come default se le datarilascio sono nulle
    select max(nvl(datarilasciofinale, dataprevistarilasciofinale)) as maxdatarilascio
    FROM rst_anagraficheebom WHERE idcommessa = 71
), 
ebom_dates as (
    select distinct ap.idanagrafica, ap.veicolocassa,ap.quantita,
    an.idcommessa, an.partnbr, an.revisione, 
    nvl(nvl(an.datarilasciofinale, an.dataprevistarilasciofinale), 
            (select maxdatarilascio from md) 
        ) as datarilascio  
    from (
        SELECT id, idcommessa, partnbr, datarilasciofinale, dataprevistarilasciofinale, revisione
        FROM (
            SELECT id, idcommessa, partnbr, datarilasciofinale, dataprevistarilasciofinale, revisione,
                   ROW_NUMBER() OVER (PARTITION BY partnbr ORDER BY revisione DESC) as rn
            FROM rst_anagraficheebom
            WHERE idcommessa = 71
        ) t
        WHERE rn = 1  order by partnbr
    ) an
    join rst_applicazioniebom ap on ap.idanagrafica = an.id 
    Where ap.quantita>0
    order by an.partnbr, veicolocassa
)
select partnbr, min(datarilascio) as datarilascio
from ebom_dates group by partnbr;

---- offset ingegneria e produzione
--         da sommare alla data di rilascio per avere la deadline dell'mbom
--         da sottrarre alla data di produzione per avere le deadline di workinstruction e routing
select Descrizione, FLGEBOM, FLGPRODUZIONE, FLGMANUALI, OFFSETENG, OFFSETPROD 
from RST_ATTIVITAWL where Descrizione in ('M-BOM', 'WORK INSTRUCTION', 'ROUTING');
--                    OFFSETENG   OFFSETPROD
-- M-BOM                 10           0
-- WORK INSTRUCTION       0          20
-- ROUTING                0           5




-----------------
-- CALCULATED

-- ebom_production_dates
--    from  casse_production_dates and  database  ... ?

-- eboms
--     {  "id": "EBOM1.DRT2",
--     "eng_release_date": datetime(2024, 5, 2),
--     "phases": [
--         {"id": 0, "name": "mbom", "deadline": datetime(2024, 5, 8), "cost": 45.2, "remaining_cost": 45.2, "active_worker": None},
--         {"id": 0, "name": "workinstruction", "deadline": datetime(2026, 5, 18), "cost": 48.1, "remaining_cost": 48.1, "active_worker": None},
--         {"id": 0, "name": "routing", "deadline": datetime(2028, 6, 2), "cost": 36.5, "remaining_cost": 36.5, "active_worker": None}
--     ] },
-- dove:
--    eng_release_date : datarilascio da db
--    deadline ebom = rst_anagraficheebom.datarilascio(EBOM) + RST_ATTIVITAWL.OFFSETENG(MBOM)
--    deadline workinstruction = minima(ebom_production_dates(EBOM su Cassa)) - RST_ATTIVITAWL.OFFSETPROD(WORKINSTRUCTION)
--    deadline routing = minima(ebom_production_dates(EBOM su Cassa)) - RST_ATTIVITAWL.OFFSETPROD(ROUTING)
 
-- START_DATE simulazione  =  MIN(data rilascio ingegneria)

-- ELAPSED_DAYS =  MIN(ebom_production_dates)  -  START_DATE















/*
SELECT min(to_date(datainizio,'dd/mm/yyyy'))  FROM RST_IMPORTAZIONEPIANOPROD WHERE IDCOMMESSA = 24 AND CASSA ='DC1' AND TRENOCOMMERCIALE='1' AND workstation='WSL010';
SELECT * FROM RST_IMPORTAZIONEPIANOPROD WHERE IDCOMMESSA = 24 AND CASSA ='DC1' AND TRENOCOMMERCIALE='1' AND workstation='WSL010';
desc RST_IMPORTAZIONEPIANOPROD;

select distinct idcommessa from RST_IMPORTAZIONEPIANOPROD order by idcommessa;
select distinct id from rst_verecommesse order by id;
select * from RST_IMPORTAZIONEPIANOPROD;
select distinct id from rst_verecommesse order by id;


select * from rst_anagraficheebom where idcommessa=24;
select distinct idcommessa from RST_IMPORTAZIONEPIANOPROD
where idcommessa is not null
and idcommessa in (select distinct idcommessa from rst_anagraficheebom);
*/
