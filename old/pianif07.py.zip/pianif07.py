import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from typing import List, Dict, Tuple
import random
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

@dataclass
class Phase:
    name: str
    duration_hours: int
    deadline: datetime
    start_date: datetime = None
    end_date: datetime = None
    assigned_worker: str = None

@dataclass
class DTR:
    id: str
    ebom_id: str
    phases: List[Phase] = field(default_factory=list)

@dataclass
class EBOM:
    id: str
    release_date: datetime
    dtrs: List[DTR] = field(default_factory=list)

class ResourceScheduler:
    def __init__(self, shift_hours=8, shifts_per_day=2, working_days_per_month=22):
        self.shift_hours = shift_hours
        self.shifts_per_day = shifts_per_day
        self.working_days_per_month = working_days_per_month
        self.hours_per_month = shift_hours * shifts_per_day * working_days_per_month
        
        self.eboms = []
        self.schedule = []
        self.monthly_workers = {}
        
    def add_ebom(self, ebom: EBOM):
        self.eboms.append(ebom)
    
    def generate_test_data(self, num_eboms=10):
        """Generate random test data"""
        self.eboms = []
        start_date = datetime(2024, 1, 1)
        
        for i in range(num_eboms):
            ebom = EBOM(
                id=f"EBOM_{i+1:03d}",
                release_date=start_date + timedelta(days=random.randint(0, 60))
            )
            
            # Each EBOM has 1-4 DTRs
            num_dtrs = random.randint(1, 4)
            for j in range(num_dtrs):
                dtr = DTR(
                    id=f"DTR_{i+1:03d}_{j+1}",
                    ebom_id=ebom.id
                )
                
                # Create 3 phases for each DTR
                base_deadline = ebom.release_date + timedelta(days=random.randint(90, 300))
                
                phases = [
                    Phase("mbom", random.randint(40, 120), base_deadline - timedelta(days=60)),
                    Phase("workInstruction", random.randint(30, 80), base_deadline - timedelta(days=30)),
                    Phase("routing", random.randint(20, 60), base_deadline)
                ]
                
                dtr.phases = phases
                ebom.dtrs.append(dtr)
            
            self.eboms.append(ebom)
    
    def calculate_schedule(self, gap_weeks=4, min_utilization=0.9, max_iterations=100):
        """Simple greedy scheduling algorithm"""
        
        # Reset schedule
        self.schedule = []
        self.monthly_workers = {}
        
        # Collect all phases with their constraints
        all_phases = []
        for ebom in self.eboms:
            for dtr in ebom.dtrs:
                for i, phase in enumerate(dtr.phases):
                    all_phases.append({
                        'phase': phase,
                        'ebom_id': ebom.id,
                        'dtr_id': dtr.id,
                        'phase_order': i,
                        'release_date': ebom.release_date,
                        'is_mbom': phase.name == 'mbom'
                    })
        
        # Sort phases by deadline
        all_phases.sort(key=lambda x: x['phase'].deadline)
        
        # Find when all MBOM phases should be completed
        mbom_phases = [p for p in all_phases if p['is_mbom']]
        if mbom_phases:
            latest_mbom_end = max(p['phase'].deadline for p in mbom_phases)
            gap_start = latest_mbom_end + timedelta(weeks=gap_weeks)
        else:
            gap_start = datetime(2024, 1, 1)
        
        # Schedule phases
        worker_schedules = {}  # worker_id -> list of (start, end, phase_info)
        worker_counter = 0
        
        for phase_info in all_phases:
            phase = phase_info['phase']
            
            # Determine earliest start date
            if phase_info['is_mbom']:
                earliest_start = max(phase_info['release_date'], datetime(2024, 1, 1))
            else:
                # Non-MBOM phases must start after the gap
                earliest_start = max(phase_info['release_date'], gap_start)
            
            # Find available worker
            assigned_worker = None
            best_start_time = None
            
            for worker_id, schedule in worker_schedules.items():
                # Check if worker can fit this task
                start_time = self.find_available_slot(schedule, earliest_start, 
                                                   phase.duration_hours, phase.deadline)
                if start_time:
                    assigned_worker = worker_id
                    best_start_time = start_time
                    break
            
            # If no worker available, create new worker
            if not assigned_worker:
                worker_counter += 1
                assigned_worker = f"Worker_{worker_counter:03d}"
                worker_schedules[assigned_worker] = []
                best_start_time = earliest_start
            
            # Check if task can meet deadline
            end_time = self.add_working_hours(best_start_time, phase.duration_hours)
            if end_time > phase.deadline:
                print(f"Warning: Task {phase_info['dtr_id']}-{phase.name} cannot meet deadline")
            
            # Assign task
            phase.start_date = best_start_time
            phase.end_date = end_time
            phase.assigned_worker = assigned_worker
            
            worker_schedules[assigned_worker].append({
                'start': best_start_time,
                'end': end_time,
                'phase': phase,
                'ebom_id': phase_info['ebom_id'],
                'dtr_id': phase_info['dtr_id']
            })
            
            self.schedule.append({
                'ebom_id': phase_info['ebom_id'],
                'dtr_id': phase_info['dtr_id'],
                'phase': phase.name,
                'worker': assigned_worker,
                'start_date': best_start_time,
                'end_date': end_time,
                'duration_hours': phase.duration_hours,
                'deadline': phase.deadline
            })
        
        # Calculate monthly worker requirements
        self.calculate_monthly_requirements(worker_schedules)
        
        return len(worker_schedules)
    
    def find_available_slot(self, worker_schedule, earliest_start, duration_hours, deadline):
        """Find available time slot for a worker"""
        if not worker_schedule:
            return earliest_start
        
        # Sort schedule by start time
        sorted_schedule = sorted(worker_schedule, key=lambda x: x['start'])
        
        # Check if task can fit before first task
        if sorted_schedule[0]['start'] >= self.add_working_hours(earliest_start, duration_hours):
            return earliest_start
        
        # Check gaps between tasks
        for i in range(len(sorted_schedule) - 1):
            gap_start = max(sorted_schedule[i]['end'], earliest_start)
            gap_end = sorted_schedule[i + 1]['start']
            
            if self.add_working_hours(gap_start, duration_hours) <= gap_end:
                return gap_start
        
        # Check after last task
        last_end = sorted_schedule[-1]['end']
        potential_start = max(last_end, earliest_start)
        if self.add_working_hours(potential_start, duration_hours) <= deadline:
            return potential_start
        
        return None
    
    def add_working_hours(self, start_date, hours):
        """Add working hours considering shifts and weekends"""
        current_date = start_date
        remaining_hours = hours
        
        while remaining_hours > 0:
            # Skip weekends
            if current_date.weekday() >= 5:  # Saturday = 5, Sunday = 6
                current_date += timedelta(days=1)
                current_date = current_date.replace(hour=8, minute=0, second=0, microsecond=0)
                continue
            
            # Calculate hours that can be worked in current day
            daily_capacity = self.shift_hours * self.shifts_per_day
            hours_today = min(remaining_hours, daily_capacity)
            
            if remaining_hours <= daily_capacity:
                # Task finishes today
                hours_to_add = hours_today / self.shifts_per_day
                return current_date + timedelta(hours=hours_to_add)
            else:
                # Task continues to next day
                remaining_hours -= daily_capacity
                current_date += timedelta(days=1)
                current_date = current_date.replace(hour=8, minute=0, second=0, microsecond=0)
        
        return current_date
    
    def calculate_monthly_requirements(self, worker_schedules):
        """Calculate how many workers needed per month"""
        self.monthly_workers = {}
        
        for worker_id, schedule in worker_schedules.items():
            for task in schedule:
                start_month = task['start'].strftime('%Y-%m')
                end_month = task['end'].strftime('%Y-%m')
                
                # Add worker to months they work in
                months = [start_month]
                if end_month != start_month:
                    months.append(end_month)
                
                for month in months:
                    if month not in self.monthly_workers:
                        self.monthly_workers[month] = set()
                    self.monthly_workers[month].add(worker_id)
        
        # Convert to counts
        for month in self.monthly_workers:
            self.monthly_workers[month] = len(self.monthly_workers[month])
    
    def create_gantt_chart(self):
        """Create Gantt chart visualization"""
        if not self.schedule:
            return None
        
        df = pd.DataFrame(self.schedule)
        
        # Create colors for different phases
        colors = {'mbom': 'blue', 'workInstruction': 'orange', 'routing': 'green'}
        df['color'] = df['phase'].map(colors)
        
        fig = px.timeline(df, 
                         x_start="start_date", 
                         x_end="end_date",
                         y="worker", 
                         color="phase",
                         hover_data=["ebom_id", "dtr_id", "duration_hours"],
                         title="Resource Scheduling Gantt Chart")
        
        fig.update_yaxes(categoryorder="total ascending")
        return fig
    
    def export_to_csv(self, filename="schedule.csv"):
        """Export schedule to CSV"""
        if self.schedule:
            df = pd.DataFrame(self.schedule)
            df.to_csv(filename, index=False)
            print(f"Schedule exported to {filename}")
    
    def print_summary(self):
        """Print scheduling summary"""
        if not self.schedule:
            print("No schedule calculated yet")
            return
        
        total_workers = len(set(task['worker'] for task in self.schedule))
        print(f"\n=== Scheduling Summary ===")
        print(f"Total EBOMs: {len(self.eboms)}")
        print(f"Total Tasks: {len(self.schedule)}")
        print(f"Total Workers Needed: {total_workers}")
        print(f"\nMonthly Worker Requirements:")
        
        for month in sorted(self.monthly_workers.keys()):
            print(f"  {month}: {self.monthly_workers[month]} workers")

def test_different_parameters():
    """Test different parameter combinations"""
    print("Testing different parameter combinations...\n")
    
    results = []
    
    # Test different gap durations and shift configurations
    gap_options = [2, 4, 6, 8]  # weeks
    shift_options = [2, 3]      # shifts per day
    
    for gap_weeks in gap_options:
        for shifts_per_day in shift_options:
            print(f"Testing: Gap={gap_weeks} weeks, Shifts={shifts_per_day}")
            
            scheduler = ResourceScheduler(shifts_per_day=shifts_per_day)
            scheduler.generate_test_data(num_eboms=8)
            
            total_workers = scheduler.calculate_schedule(gap_weeks=gap_weeks)
            max_monthly_workers = max(scheduler.monthly_workers.values()) if scheduler.monthly_workers else 0
            
            results.append({
                'gap_weeks': gap_weeks,
                'shifts_per_day': shifts_per_day,
                'total_workers': total_workers,
                'max_monthly_workers': max_monthly_workers,
                'avg_monthly_workers': np.mean(list(scheduler.monthly_workers.values())) if scheduler.monthly_workers else 0
            })
            
            print(f"  → Total workers: {total_workers}, Max monthly: {max_monthly_workers}")
            print()
    
    # Find best configuration
    best_config = min(results, key=lambda x: x['total_workers'])
    print("=== Best Configuration ===")
    print(f"Gap: {best_config['gap_weeks']} weeks")
    print(f"Shifts per day: {best_config['shifts_per_day']}")
    print(f"Total workers needed: {best_config['total_workers']}")
    print(f"Max monthly workers: {best_config['max_monthly_workers']}")
    
    return best_config

# Example usage
if __name__ == "__main__":
    # Test different parameters
    best_config = test_different_parameters()
    
    # Create detailed schedule with best parameters
    print("\n" + "="*50)
    print("Creating detailed schedule with best parameters...")
    
    scheduler = ResourceScheduler(shifts_per_day=best_config['shifts_per_day'])
    scheduler.generate_test_data(num_eboms=10)
    
    total_workers = scheduler.calculate_schedule(gap_weeks=best_config['gap_weeks'])
    scheduler.print_summary()
    
    # Create visualizations
    fig = scheduler.create_gantt_chart()
    if fig:
        fig.show()
    
    # Export to CSV
    scheduler.export_to_csv("resource_schedule.csv")
    
    print(f"\nFinal solution uses {total_workers} workers total")