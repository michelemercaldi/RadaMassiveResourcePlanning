import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import heapq
import random
from collections import defaultdict

# Configuration
SHIFT_DURATION = 7.5
MAX_TIME = 40
INTERVAL = 600  # ms between frames

# Define the graph (places and transitions with durations)
activities = ['ActivityA', 'ActivityB', 'ActivityC', 'ActivityD']
transitions = [
    ('ActivityA', 'ActivityB', 4),
    ('ActivityA', 'ActivityC', 5),  # for branching logic
    ('ActivityB', 'ActivityD', 3),
    ('ActivityC', 'ActivityD', 3),
    ('ActivityD', 'ActivityA', 2)
]

G = nx.DiGraph()
for act in activities:
    G.add_node(act)

for src, dest, duration in transitions:
    G.add_edge(src, dest, weight=duration)

pos = nx.circular_layout(G)

# Workers data
workers = {
    1: {'location': 'ActivityA', 'shift_start': 0, 'worked': 0},
    2: {'location': 'ActivityA', 'shift_start': 0, 'worked': 0}
}

# Event queue
event_queue = []

# Initial scheduling
def schedule_initial_events():
    for worker_id, data in workers.items():
        src = data['location']
        next_node = choose_next_activity(src)
        if next_node:
            duration = G[src][next_node]['weight']
            heapq.heappush(event_queue, (duration, worker_id, src, next_node))

def choose_next_activity(current_node):
    successors = list(G.successors(current_node))
    if not successors:
        return None
    # Strategy: Shortest duration first
    return min(successors, key=lambda x: G[current_node][x]['weight'])

# Start
schedule_initial_events()

# Plot setup
fig, ax = plt.subplots(figsize=(8, 6))
node_colors = ['lightblue'] * len(G.nodes())
edge_labels = {(u, v): f'{d["weight"]}h' for u, v, d in G.edges(data=True)}

def update(frame):
    global event_queue

    ax.clear()
    nx.draw(G, pos, with_labels=True, node_color=node_colors,
            node_size=2000, font_size=14, arrowsize=20, ax=ax)
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels,
                                 font_color='red', font_size=12, ax=ax)

    tokens = defaultdict(list)

    # Process events
    while event_queue and event_queue[0][0] <= frame:
        event_time, wid, src, dest = heapq.heappop(event_queue)
        worker = workers[wid]

        shift_elapsed = frame - worker['shift_start']
        duration = G[src][dest]['weight']

        # Check if activity fits in shift
        if shift_elapsed + duration > SHIFT_DURATION:
            next_shift = worker['shift_start'] + 24  # assuming 1 shift/day
            print(f"⏳ {frame:.1f}h: Worker {wid} waits for next shift at {src}")
            worker['shift_start'] = next_shift
            worker['worked'] = 0
            heapq.heappush(event_queue, (next_shift, wid, src, dest))
            continue

        print(f"✔️ {frame:.1f}h: Worker {wid} moves {src} ➡ {dest} ({duration}h)")
        worker['location'] = dest
        worker['worked'] += duration

        # Schedule next
        next_act = choose_next_activity(dest)
        if next_act:
            next_dur = G[dest][next_act]['weight']
            heapq.heappush(event_queue, (frame + next_dur, wid, dest, next_act))

    # Draw workers
    for wid, data in workers.items():
        loc = data['location']
        tokens[loc].append(wid)

    for node, wlist in tokens.items():
        x, y = pos[node]
        label = ", ".join(f"W{w}" for w in wlist)
        ax.text(x, y + 0.1, label, ha='center', fontsize=10, fontweight='bold',
                bbox=dict(facecolor='white', edgecolor='black', boxstyle='round'))

    ax.set_title(f"Time = {frame:.1f}h")
    ax.axis('off')

ani = animation.FuncAnimation(fig, update, frames=range(0, MAX_TIME + 1),
                              interval=INTERVAL, repeat=False)

plt.show()
